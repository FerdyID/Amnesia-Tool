﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Facebook;
using System.Threading;
using System.Dynamic;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Net;
using System.IO;

namespace Amnesia
{
    public partial class Main : Form
    {
        //Akses Token Facebook
        string token; 

        //Facebook Class SDK API
        private FacebookClient _fb;

        //Variable untuk menyimpan jumlah
        int amount;

        /// <summary>
        /// Menyimpan hasil ID POST
        /// </summary>
        List<string> postID = new List<string>();
        List<string> multipleID = new List<string>();

        /// <summary>
        /// Menyimpan hasil ID Groups
        /// </summary>
        List<string> groupID = new List<string>();
        List<string> multipleGroupID = new List<string>();

        //Version of this software
        private readonly string Version = "1.0.0";
        //#|------------------------------------------+
        public string getVersion()
        {
            return Version;
        }

        //Email dan Password untuk mengirim Feedback ke pihak Developer
        private string emailSender = "youremail@gmail.com";
        private string passwordSender = "emailPassword";
        //Sebuah email di mana feedback dari client akan dikirimkan
        private string emailTarget = "youremail@gmail.com";

        //Developer Facebook ID and Name
        //User tidak bisa menggunakan akses token pihak akun Developer
        //Dapat dikatakan, Amnesia tidak berfungsi untuk akun Facebook Developernya
        private string developerName = "Shin Ryu";
        private string developerID = "100000208357713";

        public Main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ///--------- Membuat Columns baru pada Listview
            /// -------- Pada Bagian Remove Memory
            listView1.Columns.Add("No", 50);
            listView1.Columns.Add("Post ID", 100);
            listView1.Columns.Add("Story", 300);
            listView1.Columns.Add("Message", 300);

            ///--------- Membuat Columns baru pada Listview
            /// -------- Pada Bagian Post Memory
            listView2.Columns.Add("No", 50);
            listView2.Columns.Add("Groups ID", 100);
            listView2.Columns.Add("Name", 200);
            listView2.Columns.Add("Privacy", 200);
            tabRemove.selected = true;

            //Check update version ke server
            checkUpdateLoad();
        }

        /// <summary>
        /// Method ini berfungsi untuk melakukan pengecekan Version ke Server
        /// </summary>
        private void checkUpdateLoad()
        {
            labelMyVersion.Text = "Your Version: V" + Version;
            bool Connection = NetworkInterface.GetIsNetworkAvailable();
            if (Connection == true)
            {

                try
                {
                    //Auto Update Notification When Program Start
                    //
                    string URL = "https://yuranicorp.github.io/Amnesia/";
                    string appName = "Amnesia.zip";
                    string serverVersion;
                    string serverVersionName = "Version.txt";

                    WebRequest req = WebRequest.Create(URL + serverVersionName);
                    WebResponse res = req.GetResponse();
                    Stream str = res.GetResponseStream();
                    StreamReader tr = new StreamReader(str);
                    serverVersion = tr.ReadLine();
                    if (getVersion() != serverVersion)
                    {
                        updateLabel.Text = "New Version: " + "V" + serverVersion;
                        DialogResult dialogresult = MessageBox.Show("New Update is out!" + "\n" + "Please update to new version", "Update Utility", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (dialogresult == DialogResult.Yes)
                        {
                            //Update Tool
                            WebClient clients = new WebClient();
                            byte[] appdata = clients.DownloadData(URL + appName);

                            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                            {
                                using (FileStream fs = System.IO.File.Create(saveFileDialog1.FileName))
                                {
                                    fs.Write(appdata, 0, appdata.Length);
                                    MessageBox.Show("Please extract into your Amnesia location to getting the new version", "Update Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                }

                            }
                        }
                        else
                        {
                            updateLabel.Text = "New Version: " + "V" + serverVersion;
                        }

                    }
                    else
                    {
                        updateLabel.Text = "Latest Version: " + "V" + Version;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString() + "\nBut you can keep continue", "Can't Connect to Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Ketika mengubah value amount maka textbox amount akan mengikuti angka value slider
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void amountSlider_ValueChanged(object sender, EventArgs e)
        {
            txtAmount.Text = amountSlider.Value.ToString();
            amount = int.Parse(txtAmount.Text);
        }


        private void btnGetAccess_Click(object sender, EventArgs e)
        {
            if (removeAction == false)
            {
                if (txtToken.Text != string.Empty)
                {
                    if (txtAmount.Text != "0")
                    {
                        token = txtToken.Text;
                        MessageBox.Show("Get Access Token Success!", "Access Token", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        listBox1.Items.Clear();
                        listBox1.Items.Add("                                                  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\[o]///////////////////////");
                        listBox1.Items.Add("                                                      [------------- [ AMNESIA TOOL ] -------------]");
                        listBox1.Items.Add("                                                      [------------ [ by Yusril Taeuchi ] ------------]");
                        listBox1.Items.Add("                                                      [--------------- [ Version: V1.0 ] ---------------]");
                        listBox1.Items.Add("                                                  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\[o]///////////////////////");
                        // Memakai Sistem Threading agar performa load post menjadi lebih ringan 
                        // Dan tidak memberatkan aplikasi
                        var load = new Thread(new ThreadStart(listLoad));
                        load.Start();
                    }
                    else
                    {
                        MessageBox.Show("Please insert Amount Value!", "Amount Wall", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please insert Access Token!", "Access Token Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        
        public void listLoad()
        {
            /* row1[0] = "1000100";
            row1[1] = "This is my story";
            row1[2] = "This is my message";
            listView1.Items.Add("1", 0).SubItems.AddRange(row1); */
            listView1.Invoke(new UpdateUi(loadPost));

        }

        private string[] row1 = { "s1", "s2", "s3" }; //Array to get Post Information
        public delegate void UpdateUi();
        public delegate void UpdateUiDone();

        /// <summary>
        /// Method ini berkerja untuk menampilkan seluruh post pada akun facebook
        /// </summary>
        public void loadPost() //Script by Yusril Takeuchi (Lee Yurani)
        {
            try
            {
                listView1.Items.Clear();
                progressBar.MaximumValue = amount;
                _fb = new FacebookClient(token);
                //--------- Menghitung total angka
                int count = 0;
                dynamic result = _fb.Get("/me/posts", new { limit = amount, offset = "0" });
                for (int i = 0; i < result.data.Count; i++)
                {
                    string ID = result.data[i].id;
                    string[] spliters = ID.Split(Convert.ToChar("_"));
                    count++;
                    row1[0] = spliters[1].ToString();
                    row1[1] = result.data[i].story;
                    row1[2] = result.data[i].message;
                    listView1.Items.Add(count.ToString(), 0).SubItems.AddRange(row1);
                    lblName.Text = result.data[i].from.name;
                    lblID.Text = result.data[i].from.id;
                    pictureBox1.Load("https://graph.facebook.com/" + lblID.Text + "/picture");
                    postID.Add(ID);
                    progressBar.Value += 1;
                }
                progressBar.Value = 0;
                progressBar.MaximumValue = count;
                //--------- Getting Total Friends
                int friends = 0;
                dynamic results = _fb.Get("/me/friends", new { limit = "5000", offset = "0" });
                for (int i = 0; i < results.data.Count; i++)
                {
                    friends++;
                    lblFriends.Text = friends.ToString() + " Friends";
                }
                /* 
                dynamic me = _fb.Get("/me/");
                MessageBox.Show(me.email); */

                /* dynamic me = _fb.Get("521424083/posts");
                MessageBox.Show(me.story); */

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        ns1.Drag dr = new ns1.Drag();
        private void panelUp_MouseDown(object sender, MouseEventArgs e)
        {
            dr.Grab(this);
        }

        private void panelUp_MouseMove(object sender, MouseEventArgs e)
        {
            dr.MoveObject(true, true);
        }

        private void panelUp_MouseUp(object sender, MouseEventArgs e)
        {
            dr.Release();
        }

        bool removeAction = false;
        private void btnRemoveAll_Click(object sender, EventArgs e)
        {
            if (removeAction == false)
            {
                if (txtToken.Text != string.Empty)
                {
                    if (lblName.Text != developerName || lblID.Text != developerID)
                    {
                        DialogResult _dialogresult = MessageBox.Show("Do you want to remove?", "Remove Post", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (_dialogresult == DialogResult.Yes)
                        {
                            removeAction = true;
                            var remove = new Thread(new ThreadStart(removeAll));
                            remove.Start();

                        }
                    }
                    else
                    {
                        MessageBox.Show("Sorry, but you can't use the developer account!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please insert Access Token First!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }

        string IDLog;
        string ErrorLog;
        int count;
        /// <summary>
        /// Method ini bekerja untuk menghapus semua Postingan yang terdeteksi.
        /// </summary>
        private void removeAll()
        {
            foreach (string ID in postID)
            {
                try
                {
                    _fb = new FacebookClient(token);
                    _fb.Delete(ID);
                    progressBar.Invoke(new UpdateUi(increaseProgressBar));
                    IDLog = ID;
                    count++;
                    listBox1.Invoke(new UpdateUi(successMessage));
                    continue;
                }
                catch (Exception ex)
                {
                    count++;
                    progressBar.Invoke(new UpdateUi(increaseProgressBar));
                    ErrorLog = ex.Message;
                    listBox1.Invoke(new UpdateUi(failureMessage));
                }

            }
            MessageBox.Show("Successfully removed all post!", "Remove Post Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listView1.Invoke(new UpdateUi(removeAllComplete));
        }

        private void successMessage()
        {
            listBox1.Items.Add("[" + count + "] " + "[Success] [" + IDLog + "] Successfully removed..");
        }

        private void failureMessage()
        {
            listBox1.Items.Add("[" + count + "] " + "[ERROR] [" + IDLog + "]" + ErrorLog);
        }



        /// <summary>
        /// Menambah value Progressbar
        /// </summary>
        public void increaseProgressBar()
        {
            progressBar.Value += 1;
        }
        public void increaseProgressBar2()
        {
            if (progressBar2.Value != progressBar2.MaximumValue)
            {
                progressBar2.Value += 1;
            }
        }

        /// <summary>
        /// Method ketika script selesai menghapus post secara menyeluruh
        /// </summary>
        public void removeAllComplete()
        {
            count = 0;
            IDLog = string.Empty;
            removeAction = false;
            ErrorLog = string.Empty;
            listView1.Items.Clear();
            txtToken.Text = string.Empty;
            amountSlider.Value = 0;
            txtAmount.Text = "0";
            progressBar.Value = 0;
            progressBar.MaximumValue = 100;
            lblID.Text = string.Empty;
            lblName.Text = string.Empty;
            lblFriends.Text = "?";
            lblName.Text = "?";
            lblID.Text = "?";
            pictureBox1.InitialImage = null;
            multipleID.Clear();
            dropdownListPost.Clear();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult _dialogresult = MessageBox.Show("Are you sure want to exit?", "Exit Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (_dialogresult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void txtToken_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        /// <summary>
        /// Bagian untuk menambahkan Post yang terpilih secara manual dan multiple
        /// Nantinya ID Post akan tersimpan ke dalam List<> dan ditampilkan dalam bentuk Dropdown
        /// </summary>
        string clickedID; //Menyimpan string pada cell yang terpilih
        //--------- Nantinya ia akan mengambil cell Post ID untuk dimasukkan ke dalam List<>
        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            clickedID = listView1.SelectedItems[0].SubItems[1].Text;
        }

        /// <summary>
        /// Menambahkan ID Post yang di dapat dari variable ClickedID lalu memasukkannya ke dalam List<> dan dropdown.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (removeAction == false)
            {
                try
                {
                    if (clickedID != string.Empty)
                    {
                        dropdownListPost.AddItem(clickedID);
                        multipleID.Add(listView1.SelectedItems[0].SubItems[1].Text);
                        for (int i = -1; i < dropdownListPost.Items.Length; i++)
                        {
                            if (i == 0)
                            {
                                dropdownListPost.selectedIndex = 0;
                            }
                            else
                            {
                                dropdownListPost.selectedIndex += 1;
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("Please choose your post first!", "Add Post", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Menghapus Post secara manual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (removeAction == false)
            {
                if (txtToken.Text != string.Empty)
                {
                    if (lblName.Text != developerName || lblID.Text != developerID)
                    {
                        DialogResult _dialogresult = MessageBox.Show("Do you want to remove?", "Remove Post", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (_dialogresult == DialogResult.Yes)
                        {
                            removeAction = true;
                            var remove = new Thread(new ThreadStart(removes));
                            remove.Start();

                        }
                    }
                    else
                    {
                        MessageBox.Show("Sorry, but you can't use the developer account!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// Menghapus beberapa post yang terpilih secara manual dari hasil penambahan
        /// di bagian Add
        /// </summary>
        private void removes()
        {
            foreach (string counts in multipleID)
            {
                count++;
            }
            progressBar.MaximumValue = count;
            foreach (string ID in multipleID)
            {
                try
                {
                    count++;
                    _fb = new FacebookClient(token);
                    _fb.Delete(lblID.Text + "_" + ID);
                    progressBar.Invoke(new UpdateUi(increaseProgressBar));
                    IDLog = ID;
                    listBox1.Invoke(new UpdateUi(successMessage));
                    continue;
                }
                catch (Exception ex)
                {
                    count++;
                    progressBar.Invoke(new UpdateUi(increaseProgressBar));
                    ErrorLog = ex.Message;
                    listBox1.Invoke(new UpdateUi(failureMessage));
                }

            }
            MessageBox.Show("Successfully removed post!", "Remove Post Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listView1.Invoke(new UpdateUi(removeAllComplete));
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPost_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
            tabPost.selected = true;
            tabRemove.selected = false;
            tabFeedback.selected = false;
            tabAbout.selected = false;
            tabUpdate.selected = false;
        }

        private void tabRemove_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
            tabPost.selected = false;
            tabRemove.selected = true;
            tabFeedback.selected = false;
            tabAbout.selected = false;
            tabUpdate.selected = false;
        }

        private void btnGetAccessToken2_Click(object sender, EventArgs e)
        {
            if (sendPost == false)
            {
                if (txtToken2.Text != string.Empty)
                {
                    if (postType == "Groups") //--------- Jika user memilih Post Type group maka ia akan menampilkan seluruh group list
                    {
                        if (txtAmountGroups.Text != "0")
                        {
                            multipleGroupID.Clear();
                            token = txtToken2.Text;
                            MessageBox.Show("Get Access Token Success!", "Access Token", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            listBox2.Items.Clear();
                            listBox2.Items.Add("                                                  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\[o]///////////////////////");
                            listBox2.Items.Add("                                                      [------------- [ AMNESIA TOOL ] -------------]");
                            listBox2.Items.Add("                                                      [------------ [ by Yusril Taeuchi ] ------------]");
                            listBox2.Items.Add("                                                      [--------------- [ Version: V1.0 ] ---------------]");
                            listBox2.Items.Add("                                                  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\[o]///////////////////////");

                            //--------- Menampilkan daftar group pada sebuah akun
                            var load = new Thread(new ThreadStart(listGroups));
                            load.Start();

                            //--------- Menampilkan informasi akun
                            var load2 = new Thread(new ThreadStart(listLoad2));
                            load2.Start();
                        }
                        else
                        {
                            MessageBox.Show("Please insert amount group!", "Amount Group", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else if (postType == "Profile") //--------- Jika user hanya memilih Post Type Profile, maka group tidak akan terload
                    {
                        token = txtToken2.Text;
                        MessageBox.Show("Get Access Token Success!", "Access Token", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        listBox2.Items.Clear();
                        listBox2.Items.Add("                                                  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\[o]///////////////////////");
                        listBox2.Items.Add("                                                      [------------- [ AMNESIA TOOL ] -------------]");
                        listBox2.Items.Add("                                                      [------------ [ by Yusril Taeuchi ] ------------]");
                        listBox2.Items.Add("                                                      [--------------- [ Version: V1.0 ] ---------------]");
                        listBox2.Items.Add("                                                  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\[o]///////////////////////");


                        //--------- Menampilkan informasi akun
                        var load2 = new Thread(new ThreadStart(listLoad2));
                        load2.Start();
                    }
                    else
                    {
                        MessageBox.Show("Please choose Post Type", "Post Type Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show("Please insert Access Token!", "Access Token Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// Memanggil method groupsDo dalam sistem Threading
        /// </summary>
        public void listGroups()
        {
            /* row1[0] = "1000100";
            row1[1] = "This is my story";
            row1[2] = "This is my message";
            listView1.Items.Add("1", 0).SubItems.AddRange(row1); */
            dropdownGroupList.Invoke(new UpdateUi(groupsDo));

        }

        /// <summary>
        /// Menampilkan seluruh group yang terdapat pada sebuah akun
        /// </summary>
        public void groupsDo() //--------- by Yusril Takeuchi
        {
            try
            {
                progressBar2.MaximumValue = int.Parse(txtAmountGroups.Text);
                listView2.Items.Clear();
                _fb = new FacebookClient(token);
                // ---------Menghitung angka
                int count = 0;
                dynamic result = _fb.Get("/me/groups", new { limit = groupsAmount, offset = "0" });
                for (int i = 0; i < result.data.Count; i++)
                {
                    string ID = result.data[i].id;
                    count++;
                    row1[0] = ID;
                    row1[1] = result.data[i].name;
                    row1[2] = result.data[i].privacy;
                    listView2.Items.Add(count.ToString(), 0).SubItems.AddRange(row1);
                    progressBar2.Value += 1;
                    groupID.Add(ID);


                }
                progressBar2.Value = 0;
                progressBar2.MaximumValue = count;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// Menyimpan jumlah group yang akan ditampilkan
        /// </summary>
        int groupsAmount;
        private void GroupsSlider_ValueChanged(object sender, EventArgs e)
        {
            txtAmountGroups.Text = GroupsSlider.Value.ToString();
            groupsAmount = int.Parse(txtAmountGroups.Text);
        }

        /// <summary>
        /// Pilihan tipe post yang mau ditampilkan pada saat update status.
        /// Jika memilih groups maka akan menampilkan daftar group sesuai angka groups amount
        /// dan mengirim post ke sebuah group secaa sekaligus.
        /// Jika memilih profile maka daftar group tidak akan ditampilkan, hanya profile biasa.
        /// Dan mengirim status ke wall profile sendiri.
        /// </summary>
        string postType;
        private void btnOKPostType_Click(object sender, EventArgs e)
        {
            if  (sendPost == false)
            {
                if (dropdownPostType.selectedIndex == 0)
                {
                    postType = "Profile";
                    MessageBox.Show("Successfully set Post Type to Profile!", "Post Type", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else if (dropdownPostType.selectedIndex == 1)
                {
                    postType = "Groups";
                    MessageBox.Show("Successfully set Post Type to Groups!", "Post Type", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// Mengirim Post
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        bool sendPost = false;
        private void btnPost_Click(object sender, EventArgs e)
        {
            if (sendPost == false)
            {
                if (lblName.Text != developerName || lblID.Text != developerID)
                {
                    sendPost = true;
                    DialogResult _dialogresult = MessageBox.Show("Do you want to post?", "Post Status", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (_dialogresult == DialogResult.Yes)
                    {
                        if (postType == "Profile")
                        {
                            btnPost.ButtonText = "Wait..";
                            PostProfile();
                        }
                        else if (postType == "Groups")
                        {
                            btnPost.ButtonText = "Wait..";
                            var postGroup = new Thread(new ThreadStart(postGroups));
                            postGroup.Start();
                        }
                        else
                        {
                            MessageBox.Show("Please choose Post Type", "Post Type Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Sorry, but you can't use the developer account!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }


        int multipleCount; //--------- Bagian menambah jumlah Group yang ingin dipost lewat metode Multiple
        //--------- Dan akan ditampilkan ke maximum progressbar2

        /// <summary>
        /// Memposting ke sebuah group dalam bentuk Select All ataupun Multiple.
        /// </summary>
        private void postGroups()
        {
            if (selectAll == true)
            {
                if (token != string.Empty)
                {
                    if (txtMessage.Text != string.Empty)
                    {
                        try
                        {
                            
                            _fb = new FacebookClient(token);
                            dynamic parameters = new ExpandoObject();
                            parameters.message = txtMessage.Text;
                            foreach (string ID in groupID)
                            {
                                try
                                {
                                    dynamic result = _fb.Post("/" + ID + "/feed", parameters);
                                    var id = result.id;
                                    progressBar2.Invoke(new UpdateUi(increaseProgressBar2));
                                    IDLog = ID;
                                    count++;
                                    listBox2.Invoke(new UpdateUi(successMessage2));
                                    continue;

                                }
                                catch(Exception ex)
                                {
                                    count++;
                                    progressBar.Invoke(new UpdateUi(increaseProgressBar));
                                    ErrorLog = ex.Message;
                                    listBox2.Invoke(new UpdateUi(failureMessage2));
                                }
 
                            }
                            
                            MessageBox.Show("Successfully updated post!", "Post Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            
                            selectAll = false;
                            txtMessage.Invoke(new UpdateUi(completeSend));
                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Post Status", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtMessage.Invoke(new UpdateUi(completeSend));
                            
                        }


                    }
                    else
                    {
                        btnPost.Invoke(new UpdateUi(failure));
                        MessageBox.Show("Please insert message!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    btnPost.Invoke(new UpdateUi(failure));
                    MessageBox.Show("Please insert access token!", "Access Token Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (multipleGroupID != null)
                {
                    if (token != string.Empty)
                    {
                        if (txtMessage.Text != string.Empty)
                        {
                            progressBar2.MaximumValue = multipleCount;

                            try
                            {
                                _fb = new FacebookClient(token);
                                dynamic parameters = new ExpandoObject();
                                parameters.message = txtMessage.Text;
                                foreach (string ID in multipleGroupID)
                                {
                                    try
                                    {
                                        dynamic result = _fb.Post("/" + ID + "/feed", parameters);
                                        var id = result.id;
                                        progressBar2.Invoke(new UpdateUi(increaseProgressBar2));
                                        IDLog = ID;
                                        count++;
                                        listBox2.Invoke(new UpdateUi(successMessage2));
                                        continue;
                                    }
                                    catch (Exception ex)
                                    {
                                        count++;
                                        progressBar.Invoke(new UpdateUi(increaseProgressBar));
                                        ErrorLog = ex.Message;
                                        listBox2.Invoke(new UpdateUi(failureMessage2));
                                    }

                                }
                                MessageBox.Show("Successfully updated post!", "Post Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtMessage.Invoke(new UpdateUi(completeSend));

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "Post Status", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txtMessage.Invoke(new UpdateUi(completeSend));
                            }


                        }
                        else
                        {
                            btnPost.Invoke(new UpdateUi(failure));
                            MessageBox.Show("Please insert message!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        btnPost.Invoke(new UpdateUi(failure));
                        MessageBox.Show("Please insert access token!", "Access Token Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    btnPost.Invoke(new UpdateUi(failure));
                    MessageBox.Show("Please add groups!", "Add Group Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void successMessage2()
        {
            listBox2.Items.Add("[" + count + "] " + "[Success] [" + IDLog + "] Successfully posted..");
        }

        private void failureMessage2()
        {
            listBox2.Items.Add("[" + count + "] " + "[ERROR] [" + IDLog + "]" + ErrorLog);
        }

        /// <summary>
        /// Mengirim post ke wall profile sendiri, jika kita memilih Post Type Profile.
        /// </summary>
        private void PostProfile()
        {
            if (token != string.Empty)
            {
                if (txtMessage.Text != string.Empty)
                {
                    try
                    {
                        progressBar2.Invoke(new UpdateUi(increaseProgressBar2));
                        _fb = new FacebookClient(token);
                        dynamic parameters = new ExpandoObject();
                        parameters.message = txtMessage.Text;
                        dynamic result = _fb.Post("me/feed/", parameters);
                        var id = result.id;
                        MessageBox.Show("Successfully updated post!", "Post Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtMessage.Invoke(new UpdateUi(completeSend));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }


                }
                else
                {
                    btnPost.Invoke(new UpdateUi(failure));
                    MessageBox.Show("Please insert message!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                btnPost.Invoke(new UpdateUi(failure));
                MessageBox.Show("Please insert access token!", "Access Token Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Bagian jika selesai mengirim post
        /// </summary>
        private void completeSend()
        {
            sendPost = false;
            count = 0;
            IDLog = string.Empty;
            ErrorLog = string.Empty;
            txtMessage.Text = string.Empty;
            txtToken2.Text = string.Empty;
            dropdownPostType.selectedIndex = -1;
            GroupsSlider.Value = 0;
            txtAmountGroups.Text = "0";
            btnSelectAll.ButtonText = "Select All";
            selectAll = false;
            btnPost.ButtonText = "Post";
            progressBar2.MaximumValue = 500;
            progressBar2.Value = 0;
            multipleCount = 0;
            multipleGroupID.Clear();
            listView2.Items.Clear();
            lblFriends.Text = "?";
            lblName.Text = "?";
            lblID.Text = "?";
            pictureBox1.InitialImage = null;
            dropdownGroupList.Clear();
        }

        /// <summary>
        /// Saat ada  bagian yang dianggap fail
        /// </summary>
        private void failure()
        {
            btnPost.ButtonText = "Post";
        }

        private void dropdownPostType_onItemSelected(object sender, EventArgs e)
        {

        }

        public void listLoad2()
        {
            /* row1[0] = "1000100";
            row1[1] = "This is my story";
            row1[2] = "This is my message";
            listView1.Items.Add("1", 0).SubItems.AddRange(row1); */
            lblName.Invoke(new UpdateUi(loadProfile));

        }

        /// <summary>
        /// Load informasi profile sendiri dan total teman
        /// </summary>
        public void loadProfile()
        {
            try
            {
                _fb = new FacebookClient(token);
                //--------- Menghitung angka
                dynamic result = _fb.Get("/me/posts", new { limit = "5", offset = "0" });
                for (int i = 0; i < result.data.Count; i++)
                {
               
                    lblName.Text = result.data[i].from.name;
                    lblID.Text = result.data[i].from.id;
                    pictureBox1.Load("https://graph.facebook.com/" + lblID.Text + "/picture");

                    //--------- Getting Total Friends
                    int friends = 0;
                    dynamic results = _fb.Get("/me/friends", new { limit = "5000", offset = "0" });
                    for (int f = 0; f < results.data.Count; f++)
                    {
                        friends++;
                        lblFriends.Text = friends.ToString() + " Friends";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        /// <summary>
        /// Method ini berkerja ketika user menambahkan group secara multiple melalui groups id
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddGroup_Click(object sender, EventArgs e)
        {
            if (sendPost == false)
            {
                if (clickedGroupsID != string.Empty)
                {
                    try
                    {
                        dropdownGroupList.AddItem(clickedGroupsID);
                        multipleGroupID.Add(listView2.SelectedItems[0].SubItems[1].Text);
                        multipleCount++;
                        for (int i = -1; i < dropdownGroupList.Items.Length; i++)
                        {
                            if (i == 0)
                            {
                                dropdownGroupList.selectedIndex = 0;
                            }
                            else
                            {
                                dropdownGroupList.selectedIndex += 1;
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show("Please choose your post first!", "Add Post", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Ketika user memilih group mana yang ingin ditambahkan, nantinya akan
        /// tersimpan dalam variable clickedGroupsID dan dimasukkan ke dalam List<>
        /// </summary>
        string clickedGroupsID;
        private void listView2_MouseClick(object sender, MouseEventArgs e)
        {
            clickedGroupsID = listView2.SelectedItems[0].SubItems[1].Text;
        }

        /// <summary>
        /// Jika user memilih tombol Select All, maka post akan terkirim ke semua group yang terload
        /// </summary>
        bool selectAll = false;
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            if (sendPost == false)
            {
                if (selectAll == false)
                {
                    selectAll = true;
                    MessageBox.Show("Set Post to All Groups!", "Post All", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnSelectAll.ButtonText = "Multiple";
                }
                else
                {
                    selectAll = false;
                    MessageBox.Show("Set Post to Multiple Manual!", "Post All", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnSelectAll.ButtonText = "Select All";
                }

            }
            else
            {
                MessageBox.Show("Can't do this action at the time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
        }

        private void tabExit_Click(object sender, EventArgs e)
        {
            DialogResult _dialogresult = MessageBox.Show("Are you sure want to exit?", "Exit Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (_dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        bool sendFeeback = false;
        public string kerja;
        public string bantu;
        public string diikuti;
        private string rating;
        private void btnFeedback_Click(object sender, EventArgs e)
        {
            if (sendFeeback == false)
            {
                sendFeeback = true;
                if (txtName.Text != string.Empty && txtSubject.Text != string.Empty && txtFeedbackMessage.Text != string.Empty)
                {
                    if (Star1.Checked || Star2.Checked || Star3.Checked || Star4.Checked || Star5.Checked == true)
                    {
                        if (Star1.Checked == true)
                        {
                            rating = Star1.Text;
                        }
                        else if (Star2.Checked == true)
                        {
                            rating = Star2.Text;
                        }
                        else if (Star3.Checked == true)
                        {
                            rating = Star3.Text;
                        }
                        else if (Star4.Checked == true)
                        {
                            rating = Star4.Text;
                        }
                        else if (Star5.Checked == true)
                        {
                            rating = Star5.Text;
                        }
        
                        btnFeedback.ButtonText = "Sending...";
                        var feedback = new Thread(new ThreadStart(sendFeedback));
                        feedback.Start();
                    }
                    else
                    {
                        MessageBox.Show("Please choose your rating!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Every forms must be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please wait before send Feedback complete!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void CompleteFeedback()
        {
            MessageBox.Show("Success sending Feedback", "Success Send", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MessageBox.Show("Thanks for your feedback to us" + "\n" + "We will fighting to make this software more awesome!", "Thank you", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btnFeedback.ButtonText = "Send Feedback";
            txtName.Text = string.Empty;
            txtSubject.Text = string.Empty;
            txtFeedbackMessage.Text = string.Empty;
            sendFeeback = false;
        }
        public void failureFeedback()
        {
            sendFeeback = false;
            btnFeedback.ButtonText = "Send Feedback";
        }

        public void sendFeedback()
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                mail.From = new MailAddress("yuranicorp@gmail.com", "Amnesia");
                mail.To.Add(emailTarget);
                mail.Subject = "New Feedback From Client | " + txtName.Text;
                mail.Body = "<head> <center><h2><b><font color=blue>New Feedback From Client</font></b></h2> <p>Feedback baru telah masuk kepada pihak Developer:</p> <p>--------------------------------------------------------------------------</p> <p>" + txtName.Text + "</p></center> </head> <body> Laporan feedback telah terkirim dari pengguna melalui software Amnesia. <p><b>+--------------------------------------------------------------------------+</b></p> <p>Client Name: " + txtName.Text + "</p>" + "<p>Subject: " + txtSubject.Text + "<p>Rating: " + rating + "</p><p>Version: V1.0.0" + "</p> <p><b>+--------------------------------------------------------------------------+</b></p> <p>" + txtMessage.Text + "</p> <p><b>+--------------------------------------------------------------------------+</p></b><br /> <center>Copyright © 2017 PR Reminder | Created by Yurani Corporation | Developed by Yusril Takeuchi</center></body>";
                mail.IsBodyHtml = true;
                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential(emailSender, passwordSender);
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnFeedback.Invoke(new UpdateUi(failureFeedback));
                return;
            }
            btnFeedback.Invoke(new UpdateUi(CompleteFeedback));
        }

        private void tabFeedback_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
            tabPost.selected = false;
            tabRemove.selected = false;
            tabFeedback.selected = true;
            tabAbout.selected = false;
            tabUpdate.selected = false;
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 3;
            tabPost.selected = false;
            tabRemove.selected = false;
            tabFeedback.selected = false;
            tabAbout.selected = true;
            tabUpdate.selected = false;
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void btnWeb_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://yuranicorp.blogspot.com/");
        }

        private void btnFacebook_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/yuranicorp/");
        }

        private void btnDonate_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.bolt.id/isi-ulang-paket-internet");
        }

        private void tabUpdate_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 4;
            tabPost.selected = false;
            tabRemove.selected = false;
            tabFeedback.selected = false;
            tabAbout.selected = false;
            tabUpdate.selected = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            bool Connection = NetworkInterface.GetIsNetworkAvailable();
            if (Connection == true)
            {
                checkForUpdate();
            }
            else
            {
                MessageBox.Show("You don't have internet connection!", "Update Utility", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void checkForUpdate()
        {
            //
            try
            {
                string URL = "https://yuranicorp.github.io/Amnesia/";
                string appName = "Amnesia.zip";
                string serverVersion;
                string serverVersionName = "Version.txt";

                WebRequest req = WebRequest.Create(URL + serverVersionName);
                WebResponse res = req.GetResponse();
                Stream str = res.GetResponseStream();
                StreamReader tr = new StreamReader(str);
                serverVersion = tr.ReadLine();

                if (getVersion() != serverVersion)
                {
                    DialogResult dialogresult = MessageBox.Show("New Update is out!" + "\n" + "Please update to new version", "Update Utility", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (dialogresult == DialogResult.Yes)
                    {
                        //Update Tool
                        WebClient clients = new WebClient();
                        byte[] appdata = clients.DownloadData(URL + appName);

                        if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                        {
                            using (FileStream fs = System.IO.File.Create(saveFileDialog1.FileName))
                            {
                                fs.Write(appdata, 0, appdata.Length);
                                MessageBox.Show("Please extract into your PR Reminder location to getting the new version", "Update Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            }

                        }
                    }

                }
                else
                {
                    MessageBox.Show("You already have the latest version", "Update Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString() + "\nBut you can keep continue", "Can't Connect to Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


    }
}
