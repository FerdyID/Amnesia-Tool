﻿namespace Amnesia
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.listView1 = new System.Windows.Forms.ListView();
            this.bunifuElipse1 = new ns1.BunifuElipse(this.components);
            this.progressBar = new ns1.BunifuProgressBar();
            this.panelUp = new ns1.BunifuGradientPanel();
            this.btnExit = new ns1.BunifuImageButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel1 = new ns1.BunifuCustomLabel();
            this.txtToken = new ns1.BunifuMaterialTextbox();
            this.amountSlider = new ns1.BunifuSlider();
            this.txtAmount = new ns1.BunifuMaterialTextbox();
            this.lblName = new ns1.BunifuCustomLabel();
            this.lblID = new ns1.BunifuCustomLabel();
            this.bunifuSeparator1 = new ns1.BunifuSeparator();
            this.bunifuGradientPanel1 = new ns1.BunifuGradientPanel();
            this.tabUpdate = new ns1.BunifuFlatButton();
            this.lblFriends = new ns1.BunifuCustomLabel();
            this.tabFeedback = new ns1.BunifuFlatButton();
            this.tabExit = new ns1.BunifuFlatButton();
            this.tabAbout = new ns1.BunifuFlatButton();
            this.tabPost = new ns1.BunifuFlatButton();
            this.tabRemove = new ns1.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuSeparator2 = new ns1.BunifuSeparator();
            this.bunifuSeparator3 = new ns1.BunifuSeparator();
            this.bunifuSeparator5 = new ns1.BunifuSeparator();
            this.bunifuSeparator4 = new ns1.BunifuSeparator();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.bunifuCustomLabel13 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator53 = new ns1.BunifuSeparator();
            this.bunifuSeparator51 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel7 = new ns1.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator19 = new ns1.BunifuSeparator();
            this.bunifuSeparator18 = new ns1.BunifuSeparator();
            this.bunifuSeparator20 = new ns1.BunifuSeparator();
            this.btnAdd = new ns1.BunifuThinButton2();
            this.btnRemove = new ns1.BunifuThinButton2();
            this.dropdownListPost = new ns1.BunifuDropdown();
            this.bunifuCustomLabel4 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator15 = new ns1.BunifuSeparator();
            this.bunifuSeparator14 = new ns1.BunifuSeparator();
            this.btnRemoveAll = new ns1.BunifuThinButton2();
            this.btnGetAccess = new ns1.BunifuThinButton2();
            this.bunifuCustomLabel3 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator11 = new ns1.BunifuSeparator();
            this.bunifuSeparator6 = new ns1.BunifuSeparator();
            this.bunifuSeparator10 = new ns1.BunifuSeparator();
            this.bunifuSeparator7 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel2 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator12 = new ns1.BunifuSeparator();
            this.bunifuSeparator16 = new ns1.BunifuSeparator();
            this.bunifuSeparator17 = new ns1.BunifuSeparator();
            this.bunifuSeparator13 = new ns1.BunifuSeparator();
            this.bunifuSeparator21 = new ns1.BunifuSeparator();
            this.bunifuSeparator9 = new ns1.BunifuSeparator();
            this.bunifuSeparator8 = new ns1.BunifuSeparator();
            this.bunifuSeparator52 = new ns1.BunifuSeparator();
            this.bunifuSeparator54 = new ns1.BunifuSeparator();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.bunifuCustomLabel14 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator55 = new ns1.BunifuSeparator();
            this.bunifuSeparator56 = new ns1.BunifuSeparator();
            this.bunifuSeparator57 = new ns1.BunifuSeparator();
            this.bunifuSeparator58 = new ns1.BunifuSeparator();
            this.bunifuSeparator34 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel12 = new ns1.BunifuCustomLabel();
            this.listView2 = new System.Windows.Forms.ListView();
            this.bunifuSeparator46 = new ns1.BunifuSeparator();
            this.bunifuSeparator47 = new ns1.BunifuSeparator();
            this.btnPost = new ns1.BunifuThinButton2();
            this.bunifuCustomLabel11 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator43 = new ns1.BunifuSeparator();
            this.bunifuSeparator42 = new ns1.BunifuSeparator();
            this.btnOKPostType = new ns1.BunifuThinButton2();
            this.dropdownPostType = new ns1.BunifuDropdown();
            this.btnSelectAll = new ns1.BunifuThinButton2();
            this.bunifuCustomLabel10 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator38 = new ns1.BunifuSeparator();
            this.bunifuSeparator39 = new ns1.BunifuSeparator();
            this.txtAmountGroups = new ns1.BunifuMaterialTextbox();
            this.GroupsSlider = new ns1.BunifuSlider();
            this.bunifuSeparator40 = new ns1.BunifuSeparator();
            this.bunifuSeparator41 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel9 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator35 = new ns1.BunifuSeparator();
            this.btnAddGroup = new ns1.BunifuThinButton2();
            this.dropdownGroupList = new ns1.BunifuDropdown();
            this.bunifuCustomLabel8 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator30 = new ns1.BunifuSeparator();
            this.bunifuSeparator33 = new ns1.BunifuSeparator();
            this.bunifuSeparator32 = new ns1.BunifuSeparator();
            this.bunifuSeparator31 = new ns1.BunifuSeparator();
            this.txtMessage = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.progressBar2 = new ns1.BunifuProgressBar();
            this.bunifuSeparator26 = new ns1.BunifuSeparator();
            this.bunifuSeparator27 = new ns1.BunifuSeparator();
            this.bunifuSeparator28 = new ns1.BunifuSeparator();
            this.bunifuSeparator29 = new ns1.BunifuSeparator();
            this.txtToken2 = new ns1.BunifuMaterialTextbox();
            this.bunifuCustomLabel6 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator22 = new ns1.BunifuSeparator();
            this.bunifuSeparator23 = new ns1.BunifuSeparator();
            this.btnGetAccessToken2 = new ns1.BunifuThinButton2();
            this.bunifuSeparator25 = new ns1.BunifuSeparator();
            this.bunifuSeparator24 = new ns1.BunifuSeparator();
            this.bunifuSeparator37 = new ns1.BunifuSeparator();
            this.bunifuSeparator44 = new ns1.BunifuSeparator();
            this.bunifuSeparator45 = new ns1.BunifuSeparator();
            this.bunifuSeparator50 = new ns1.BunifuSeparator();
            this.bunifuSeparator49 = new ns1.BunifuSeparator();
            this.bunifuSeparator36 = new ns1.BunifuSeparator();
            this.bunifuSeparator48 = new ns1.BunifuSeparator();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.bunifuCustomLabel20 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator67 = new ns1.BunifuSeparator();
            this.bunifuSeparator65 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel19 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator64 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel18 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator60 = new ns1.BunifuSeparator();
            this.bunifuSeparator61 = new ns1.BunifuSeparator();
            this.bunifuSeparator62 = new ns1.BunifuSeparator();
            this.bunifuSeparator63 = new ns1.BunifuSeparator();
            this.Star5 = new System.Windows.Forms.RadioButton();
            this.Star4 = new System.Windows.Forms.RadioButton();
            this.Star3 = new System.Windows.Forms.RadioButton();
            this.Star2 = new System.Windows.Forms.RadioButton();
            this.Star1 = new System.Windows.Forms.RadioButton();
            this.txtName = new ns1.BunifuMaterialTextbox();
            this.bunifuCustomLabel17 = new ns1.BunifuCustomLabel();
            this.btnFeedback = new ns1.BunifuThinButton2();
            this.txtFeedbackMessage = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.bunifuCustomLabel15 = new ns1.BunifuCustomLabel();
            this.txtSubject = new ns1.BunifuMaterialTextbox();
            this.bunifuCustomLabel16 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator66 = new ns1.BunifuSeparator();
            this.bunifuSeparator59 = new ns1.BunifuSeparator();
            this.bunifuSeparator68 = new ns1.BunifuSeparator();
            this.bunifuSeparator69 = new ns1.BunifuSeparator();
            this.bunifuSeparator70 = new ns1.BunifuSeparator();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bunifuCustomLabel28 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator78 = new ns1.BunifuSeparator();
            this.bunifuSeparator75 = new ns1.BunifuSeparator();
            this.btnFacebook = new ns1.BunifuThinButton2();
            this.btnWeb = new ns1.BunifuThinButton2();
            this.btnDonate = new ns1.BunifuThinButton2();
            this.bunifuCustomLabel27 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator71 = new ns1.BunifuSeparator();
            this.bunifuSeparator72 = new ns1.BunifuSeparator();
            this.bunifuSeparator73 = new ns1.BunifuSeparator();
            this.bunifuSeparator74 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel26 = new ns1.BunifuCustomLabel();
            this.bunifuCustomLabel25 = new ns1.BunifuCustomLabel();
            this.bunifuCustomLabel24 = new ns1.BunifuCustomLabel();
            this.bunifuCustomLabel23 = new ns1.BunifuCustomLabel();
            this.bunifuCustomLabel22 = new ns1.BunifuCustomLabel();
            this.bunifuCustomLabel21 = new ns1.BunifuCustomLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.bunifuSeparator76 = new ns1.BunifuSeparator();
            this.bunifuSeparator77 = new ns1.BunifuSeparator();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.bunifuCustomLabel32 = new ns1.BunifuCustomLabel();
            this.bunifuSeparator81 = new ns1.BunifuSeparator();
            this.bunifuSeparator79 = new ns1.BunifuSeparator();
            this.bunifuCustomLabel31 = new ns1.BunifuCustomLabel();
            this.updateLabel = new ns1.BunifuCustomLabel();
            this.labelMyVersion = new ns1.BunifuCustomLabel();
            this.btnUpdate = new ns1.BunifuThinButton2();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.bunifuSeparator80 = new ns1.BunifuSeparator();
            this.bunifuSeparator82 = new ns1.BunifuSeparator();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panelUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.listView1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.ForeColor = System.Drawing.Color.Silver;
            this.listView1.Location = new System.Drawing.Point(285, 261);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(615, 197);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseClick);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // progressBar
            // 
            this.progressBar.BackColor = System.Drawing.Color.Silver;
            this.progressBar.BorderRadius = 5;
            this.progressBar.Location = new System.Drawing.Point(285, 464);
            this.progressBar.MaximumValue = 100;
            this.progressBar.Name = "progressBar";
            this.progressBar.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.progressBar.Size = new System.Drawing.Size(615, 8);
            this.progressBar.TabIndex = 1;
            this.progressBar.Value = 0;
            // 
            // panelUp
            // 
            this.panelUp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelUp.BackgroundImage")));
            this.panelUp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelUp.Controls.Add(this.btnExit);
            this.panelUp.Controls.Add(this.pictureBox2);
            this.panelUp.Controls.Add(this.bunifuCustomLabel1);
            this.panelUp.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.panelUp.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.panelUp.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.panelUp.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.panelUp.Location = new System.Drawing.Point(0, 0);
            this.panelUp.Name = "panelUp";
            this.panelUp.Quality = 10;
            this.panelUp.Size = new System.Drawing.Size(938, 37);
            this.panelUp.TabIndex = 2;
            this.panelUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelUp_MouseDown);
            this.panelUp.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelUp_MouseMove);
            this.panelUp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelUp_MouseUp);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageActive = null;
            this.btnExit.Location = new System.Drawing.Point(905, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(15, 15);
            this.btnExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnExit.TabIndex = 9;
            this.btnExit.TabStop = false;
            this.btnExit.Zoom = 10;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(23, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(216)))), ((int)(((byte)(255)))));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(59, 8);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(78, 19);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Amnesia";
            // 
            // txtToken
            // 
            this.txtToken.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtToken.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtToken.ForeColor = System.Drawing.Color.Silver;
            this.txtToken.HintForeColor = System.Drawing.Color.Silver;
            this.txtToken.HintText = "Your Facebook Access Token";
            this.txtToken.isPassword = false;
            this.txtToken.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtToken.LineIdleColor = System.Drawing.Color.Silver;
            this.txtToken.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtToken.LineThickness = 3;
            this.txtToken.Location = new System.Drawing.Point(285, 28);
            this.txtToken.Margin = new System.Windows.Forms.Padding(4);
            this.txtToken.Name = "txtToken";
            this.txtToken.Size = new System.Drawing.Size(514, 33);
            this.txtToken.TabIndex = 0;
            this.txtToken.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtToken.OnValueChanged += new System.EventHandler(this.txtToken_OnValueChanged);
            // 
            // amountSlider
            // 
            this.amountSlider.BackColor = System.Drawing.Color.Transparent;
            this.amountSlider.BackgroudColor = System.Drawing.Color.Silver;
            this.amountSlider.BorderRadius = 0;
            this.amountSlider.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.amountSlider.Location = new System.Drawing.Point(274, 108);
            this.amountSlider.MaximumValue = 500;
            this.amountSlider.Name = "amountSlider";
            this.amountSlider.Size = new System.Drawing.Size(482, 30);
            this.amountSlider.TabIndex = 6;
            this.amountSlider.Value = 0;
            this.amountSlider.ValueChanged += new System.EventHandler(this.amountSlider_ValueChanged);
            // 
            // txtAmount
            // 
            this.txtAmount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAmount.Enabled = false;
            this.txtAmount.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtAmount.ForeColor = System.Drawing.Color.Silver;
            this.txtAmount.HintForeColor = System.Drawing.Color.Silver;
            this.txtAmount.HintText = "";
            this.txtAmount.isPassword = false;
            this.txtAmount.LineFocusedColor = System.Drawing.Color.Silver;
            this.txtAmount.LineIdleColor = System.Drawing.Color.Silver;
            this.txtAmount.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtAmount.LineThickness = 3;
            this.txtAmount.Location = new System.Drawing.Point(763, 108);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(4);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(51, 33);
            this.txtAmount.TabIndex = 5;
            this.txtAmount.Text = "0";
            this.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblName
            // 
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Silver;
            this.lblName.Location = new System.Drawing.Point(3, 145);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(255, 18);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "?";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblID
            // 
            this.lblID.BackColor = System.Drawing.Color.Transparent;
            this.lblID.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.ForeColor = System.Drawing.Color.Silver;
            this.lblID.Location = new System.Drawing.Point(3, 115);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(255, 24);
            this.lblID.TabIndex = 6;
            this.lblID.Text = "?";
            this.lblID.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator1.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(81, 195);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(93, 15);
            this.bunifuSeparator1.TabIndex = 1;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.tabUpdate);
            this.bunifuGradientPanel1.Controls.Add(this.lblFriends);
            this.bunifuGradientPanel1.Controls.Add(this.tabFeedback);
            this.bunifuGradientPanel1.Controls.Add(this.tabExit);
            this.bunifuGradientPanel1.Controls.Add(this.tabAbout);
            this.bunifuGradientPanel1.Controls.Add(this.tabPost);
            this.bunifuGradientPanel1.Controls.Add(this.tabRemove);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.lblID);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.lblName);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator5);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator4);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 33);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(264, 578);
            this.bunifuGradientPanel1.TabIndex = 7;
            // 
            // tabUpdate
            // 
            this.tabUpdate.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabUpdate.BorderRadius = 0;
            this.tabUpdate.ButtonText = "       Update";
            this.tabUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabUpdate.DisabledColor = System.Drawing.Color.Gray;
            this.tabUpdate.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabUpdate.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabUpdate.Iconcolor = System.Drawing.Color.Transparent;
            this.tabUpdate.Iconimage = ((System.Drawing.Image)(resources.GetObject("tabUpdate.Iconimage")));
            this.tabUpdate.Iconimage_right = null;
            this.tabUpdate.Iconimage_right_Selected = null;
            this.tabUpdate.Iconimage_Selected = null;
            this.tabUpdate.IconMarginLeft = 0;
            this.tabUpdate.IconMarginRight = 0;
            this.tabUpdate.IconRightVisible = true;
            this.tabUpdate.IconRightZoom = 0D;
            this.tabUpdate.IconVisible = true;
            this.tabUpdate.IconZoom = 60D;
            this.tabUpdate.IsTab = true;
            this.tabUpdate.Location = new System.Drawing.Point(2, 365);
            this.tabUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.tabUpdate.Name = "tabUpdate";
            this.tabUpdate.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabUpdate.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabUpdate.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabUpdate.selected = false;
            this.tabUpdate.Size = new System.Drawing.Size(257, 50);
            this.tabUpdate.TabIndex = 20;
            this.tabUpdate.Text = "       Update";
            this.tabUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabUpdate.Textcolor = System.Drawing.Color.Silver;
            this.tabUpdate.TextFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabUpdate.Click += new System.EventHandler(this.tabUpdate_Click);
            // 
            // lblFriends
            // 
            this.lblFriends.BackColor = System.Drawing.Color.Transparent;
            this.lblFriends.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFriends.ForeColor = System.Drawing.Color.Silver;
            this.lblFriends.Location = new System.Drawing.Point(3, 174);
            this.lblFriends.Name = "lblFriends";
            this.lblFriends.Size = new System.Drawing.Size(255, 18);
            this.lblFriends.TabIndex = 19;
            this.lblFriends.Text = "?";
            this.lblFriends.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabFeedback
            // 
            this.tabFeedback.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabFeedback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabFeedback.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabFeedback.BorderRadius = 0;
            this.tabFeedback.ButtonText = "       Feedback";
            this.tabFeedback.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabFeedback.DisabledColor = System.Drawing.Color.Gray;
            this.tabFeedback.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabFeedback.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabFeedback.Iconcolor = System.Drawing.Color.Transparent;
            this.tabFeedback.Iconimage = ((System.Drawing.Image)(resources.GetObject("tabFeedback.Iconimage")));
            this.tabFeedback.Iconimage_right = null;
            this.tabFeedback.Iconimage_right_Selected = null;
            this.tabFeedback.Iconimage_Selected = null;
            this.tabFeedback.IconMarginLeft = 0;
            this.tabFeedback.IconMarginRight = 0;
            this.tabFeedback.IconRightVisible = true;
            this.tabFeedback.IconRightZoom = 0D;
            this.tabFeedback.IconVisible = true;
            this.tabFeedback.IconZoom = 60D;
            this.tabFeedback.IsTab = true;
            this.tabFeedback.Location = new System.Drawing.Point(2, 316);
            this.tabFeedback.Margin = new System.Windows.Forms.Padding(4);
            this.tabFeedback.Name = "tabFeedback";
            this.tabFeedback.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabFeedback.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabFeedback.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabFeedback.selected = false;
            this.tabFeedback.Size = new System.Drawing.Size(257, 50);
            this.tabFeedback.TabIndex = 18;
            this.tabFeedback.Text = "       Feedback";
            this.tabFeedback.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabFeedback.Textcolor = System.Drawing.Color.Silver;
            this.tabFeedback.TextFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabFeedback.Click += new System.EventHandler(this.tabFeedback_Click);
            // 
            // tabExit
            // 
            this.tabExit.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabExit.BorderRadius = 0;
            this.tabExit.ButtonText = "        Exit";
            this.tabExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabExit.DisabledColor = System.Drawing.Color.Gray;
            this.tabExit.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabExit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabExit.Iconcolor = System.Drawing.Color.Transparent;
            this.tabExit.Iconimage = ((System.Drawing.Image)(resources.GetObject("tabExit.Iconimage")));
            this.tabExit.Iconimage_right = null;
            this.tabExit.Iconimage_right_Selected = null;
            this.tabExit.Iconimage_Selected = null;
            this.tabExit.IconMarginLeft = 0;
            this.tabExit.IconMarginRight = 0;
            this.tabExit.IconRightVisible = true;
            this.tabExit.IconRightZoom = 0D;
            this.tabExit.IconVisible = true;
            this.tabExit.IconZoom = 60D;
            this.tabExit.IsTab = true;
            this.tabExit.Location = new System.Drawing.Point(2, 463);
            this.tabExit.Margin = new System.Windows.Forms.Padding(4);
            this.tabExit.Name = "tabExit";
            this.tabExit.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabExit.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabExit.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabExit.selected = false;
            this.tabExit.Size = new System.Drawing.Size(257, 50);
            this.tabExit.TabIndex = 13;
            this.tabExit.Text = "        Exit";
            this.tabExit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabExit.Textcolor = System.Drawing.Color.Silver;
            this.tabExit.TextFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabExit.Click += new System.EventHandler(this.tabExit_Click);
            // 
            // tabAbout
            // 
            this.tabAbout.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabAbout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabAbout.BorderRadius = 0;
            this.tabAbout.ButtonText = "       About";
            this.tabAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabAbout.DisabledColor = System.Drawing.Color.Gray;
            this.tabAbout.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabAbout.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabAbout.Iconcolor = System.Drawing.Color.Transparent;
            this.tabAbout.Iconimage = ((System.Drawing.Image)(resources.GetObject("tabAbout.Iconimage")));
            this.tabAbout.Iconimage_right = null;
            this.tabAbout.Iconimage_right_Selected = null;
            this.tabAbout.Iconimage_Selected = null;
            this.tabAbout.IconMarginLeft = 0;
            this.tabAbout.IconMarginRight = 0;
            this.tabAbout.IconRightVisible = true;
            this.tabAbout.IconRightZoom = 0D;
            this.tabAbout.IconVisible = true;
            this.tabAbout.IconZoom = 60D;
            this.tabAbout.IsTab = true;
            this.tabAbout.Location = new System.Drawing.Point(2, 414);
            this.tabAbout.Margin = new System.Windows.Forms.Padding(4);
            this.tabAbout.Name = "tabAbout";
            this.tabAbout.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabAbout.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabAbout.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabAbout.selected = false;
            this.tabAbout.Size = new System.Drawing.Size(257, 50);
            this.tabAbout.TabIndex = 12;
            this.tabAbout.Text = "       About";
            this.tabAbout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabAbout.Textcolor = System.Drawing.Color.Silver;
            this.tabAbout.TextFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabAbout.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // tabPost
            // 
            this.tabPost.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabPost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabPost.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPost.BorderRadius = 0;
            this.tabPost.ButtonText = "        Post Memory";
            this.tabPost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabPost.DisabledColor = System.Drawing.Color.Gray;
            this.tabPost.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPost.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPost.Iconcolor = System.Drawing.Color.Transparent;
            this.tabPost.Iconimage = ((System.Drawing.Image)(resources.GetObject("tabPost.Iconimage")));
            this.tabPost.Iconimage_right = null;
            this.tabPost.Iconimage_right_Selected = null;
            this.tabPost.Iconimage_Selected = null;
            this.tabPost.IconMarginLeft = 0;
            this.tabPost.IconMarginRight = 0;
            this.tabPost.IconRightVisible = true;
            this.tabPost.IconRightZoom = 0D;
            this.tabPost.IconVisible = true;
            this.tabPost.IconZoom = 50D;
            this.tabPost.IsTab = true;
            this.tabPost.Location = new System.Drawing.Point(2, 267);
            this.tabPost.Margin = new System.Windows.Forms.Padding(4);
            this.tabPost.Name = "tabPost";
            this.tabPost.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabPost.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabPost.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabPost.selected = false;
            this.tabPost.Size = new System.Drawing.Size(257, 50);
            this.tabPost.TabIndex = 11;
            this.tabPost.Text = "        Post Memory";
            this.tabPost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabPost.Textcolor = System.Drawing.Color.Silver;
            this.tabPost.TextFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPost.Click += new System.EventHandler(this.tabPost_Click);
            // 
            // tabRemove
            // 
            this.tabRemove.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabRemove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabRemove.BorderRadius = 0;
            this.tabRemove.ButtonText = "       Remove Memory";
            this.tabRemove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabRemove.DisabledColor = System.Drawing.Color.Gray;
            this.tabRemove.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabRemove.ForeColor = System.Drawing.Color.Silver;
            this.tabRemove.Iconcolor = System.Drawing.Color.Transparent;
            this.tabRemove.Iconimage = ((System.Drawing.Image)(resources.GetObject("tabRemove.Iconimage")));
            this.tabRemove.Iconimage_right = null;
            this.tabRemove.Iconimage_right_Selected = null;
            this.tabRemove.Iconimage_Selected = null;
            this.tabRemove.IconMarginLeft = 0;
            this.tabRemove.IconMarginRight = 0;
            this.tabRemove.IconRightVisible = true;
            this.tabRemove.IconRightZoom = 0D;
            this.tabRemove.IconVisible = true;
            this.tabRemove.IconZoom = 60D;
            this.tabRemove.IsTab = true;
            this.tabRemove.Location = new System.Drawing.Point(2, 218);
            this.tabRemove.Margin = new System.Windows.Forms.Padding(4);
            this.tabRemove.Name = "tabRemove";
            this.tabRemove.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabRemove.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.tabRemove.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.tabRemove.selected = true;
            this.tabRemove.Size = new System.Drawing.Size(257, 50);
            this.tabRemove.TabIndex = 10;
            this.tabRemove.Text = "       Remove Memory";
            this.tabRemove.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabRemove.Textcolor = System.Drawing.Color.Silver;
            this.tabRemove.TextFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabRemove.Click += new System.EventHandler(this.tabRemove_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Location = new System.Drawing.Point(81, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(93, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator2.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(81, 98);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(93, 15);
            this.bunifuSeparator2.TabIndex = 14;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator3.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(81, 11);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(93, 15);
            this.bunifuSeparator3.TabIndex = 15;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator5.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(75, 18);
            this.bunifuSeparator5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(10, 88);
            this.bunifuSeparator5.TabIndex = 17;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = true;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator4.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(169, 18);
            this.bunifuSeparator4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(10, 88);
            this.bunifuSeparator4.TabIndex = 16;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(938, 607);
            this.panel1.TabIndex = 8;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(0, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(950, 599);
            this.tabControl1.TabIndex = 41;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Controls.Add(this.bunifuCustomLabel13);
            this.tabPage1.Controls.Add(this.bunifuSeparator53);
            this.tabPage1.Controls.Add(this.bunifuSeparator51);
            this.tabPage1.Controls.Add(this.bunifuCustomLabel7);
            this.tabPage1.Controls.Add(this.bunifuCustomLabel5);
            this.tabPage1.Controls.Add(this.txtToken);
            this.tabPage1.Controls.Add(this.bunifuSeparator19);
            this.tabPage1.Controls.Add(this.bunifuSeparator18);
            this.tabPage1.Controls.Add(this.bunifuSeparator20);
            this.tabPage1.Controls.Add(this.btnAdd);
            this.tabPage1.Controls.Add(this.btnRemove);
            this.tabPage1.Controls.Add(this.dropdownListPost);
            this.tabPage1.Controls.Add(this.bunifuCustomLabel4);
            this.tabPage1.Controls.Add(this.bunifuSeparator15);
            this.tabPage1.Controls.Add(this.bunifuSeparator14);
            this.tabPage1.Controls.Add(this.btnRemoveAll);
            this.tabPage1.Controls.Add(this.btnGetAccess);
            this.tabPage1.Controls.Add(this.progressBar);
            this.tabPage1.Controls.Add(this.bunifuCustomLabel3);
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Controls.Add(this.bunifuSeparator11);
            this.tabPage1.Controls.Add(this.bunifuSeparator6);
            this.tabPage1.Controls.Add(this.bunifuSeparator10);
            this.tabPage1.Controls.Add(this.bunifuSeparator7);
            this.tabPage1.Controls.Add(this.txtAmount);
            this.tabPage1.Controls.Add(this.amountSlider);
            this.tabPage1.Controls.Add(this.bunifuCustomLabel2);
            this.tabPage1.Controls.Add(this.bunifuSeparator12);
            this.tabPage1.Controls.Add(this.bunifuSeparator16);
            this.tabPage1.Controls.Add(this.bunifuSeparator17);
            this.tabPage1.Controls.Add(this.bunifuSeparator13);
            this.tabPage1.Controls.Add(this.bunifuSeparator21);
            this.tabPage1.Controls.Add(this.bunifuSeparator9);
            this.tabPage1.Controls.Add(this.bunifuSeparator8);
            this.tabPage1.Controls.Add(this.bunifuSeparator52);
            this.tabPage1.Controls.Add(this.bunifuSeparator54);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(942, 573);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Remove Memory";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.Silver;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(282, 508);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(618, 50);
            this.listBox1.TabIndex = 42;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(282, 489);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(30, 16);
            this.bunifuCustomLabel13.TabIndex = 47;
            this.bunifuCustomLabel13.Text = "Log ";
            // 
            // bunifuSeparator53
            // 
            this.bunifuSeparator53.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator53.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator53.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator53.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator53.LineThickness = 1;
            this.bunifuSeparator53.Location = new System.Drawing.Point(267, 558);
            this.bunifuSeparator53.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator53.Name = "bunifuSeparator53";
            this.bunifuSeparator53.Size = new System.Drawing.Size(650, 15);
            this.bunifuSeparator53.TabIndex = 45;
            this.bunifuSeparator53.Transparency = 255;
            this.bunifuSeparator53.Vertical = false;
            // 
            // bunifuSeparator51
            // 
            this.bunifuSeparator51.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator51.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator51.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator51.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator51.LineThickness = 1;
            this.bunifuSeparator51.Location = new System.Drawing.Point(267, 493);
            this.bunifuSeparator51.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator51.Name = "bunifuSeparator51";
            this.bunifuSeparator51.Size = new System.Drawing.Size(650, 15);
            this.bunifuSeparator51.TabIndex = 43;
            this.bunifuSeparator51.Transparency = 255;
            this.bunifuSeparator51.Vertical = false;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(282, 238);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(74, 16);
            this.bunifuCustomLabel7.TabIndex = 41;
            this.bunifuCustomLabel7.Text = "Wall Post List";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(282, 164);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(166, 16);
            this.bunifuCustomLabel5.TabIndex = 40;
            this.bunifuCustomLabel5.Text = "Multiple Select Post (Manual)";
            // 
            // bunifuSeparator19
            // 
            this.bunifuSeparator19.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator19.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator19.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator19.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator19.LineThickness = 1;
            this.bunifuSeparator19.Location = new System.Drawing.Point(269, 219);
            this.bunifuSeparator19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator19.Name = "bunifuSeparator19";
            this.bunifuSeparator19.Size = new System.Drawing.Size(403, 15);
            this.bunifuSeparator19.TabIndex = 37;
            this.bunifuSeparator19.Transparency = 255;
            this.bunifuSeparator19.Vertical = false;
            // 
            // bunifuSeparator18
            // 
            this.bunifuSeparator18.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator18.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator18.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator18.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator18.LineThickness = 1;
            this.bunifuSeparator18.Location = new System.Drawing.Point(269, 165);
            this.bunifuSeparator18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator18.Name = "bunifuSeparator18";
            this.bunifuSeparator18.Size = new System.Drawing.Size(403, 15);
            this.bunifuSeparator18.TabIndex = 36;
            this.bunifuSeparator18.Transparency = 255;
            this.bunifuSeparator18.Vertical = false;
            // 
            // bunifuSeparator20
            // 
            this.bunifuSeparator20.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator20.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator20.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator20.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator20.LineThickness = 1;
            this.bunifuSeparator20.Location = new System.Drawing.Point(263, 172);
            this.bunifuSeparator20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator20.Name = "bunifuSeparator20";
            this.bunifuSeparator20.Size = new System.Drawing.Size(10, 55);
            this.bunifuSeparator20.TabIndex = 38;
            this.bunifuSeparator20.Transparency = 255;
            this.bunifuSeparator20.Vertical = true;
            // 
            // btnAdd
            // 
            this.btnAdd.ActiveBorderThickness = 1;
            this.btnAdd.ActiveCornerRadius = 20;
            this.btnAdd.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnAdd.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnAdd.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.ButtonText = "Add";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.Silver;
            this.btnAdd.IdleBorderThickness = 1;
            this.btnAdd.IdleCornerRadius = 20;
            this.btnAdd.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnAdd.IdleForecolor = System.Drawing.Color.Silver;
            this.btnAdd.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnAdd.Location = new System.Drawing.Point(544, 182);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(97, 36);
            this.btnAdd.TabIndex = 35;
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.ActiveBorderThickness = 1;
            this.btnRemove.ActiveCornerRadius = 20;
            this.btnRemove.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnRemove.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnRemove.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnRemove.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRemove.BackgroundImage")));
            this.btnRemove.ButtonText = "Remove";
            this.btnRemove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemove.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.ForeColor = System.Drawing.Color.Silver;
            this.btnRemove.IdleBorderThickness = 1;
            this.btnRemove.IdleCornerRadius = 20;
            this.btnRemove.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnRemove.IdleForecolor = System.Drawing.Color.Silver;
            this.btnRemove.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnRemove.Location = new System.Drawing.Point(830, 87);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(97, 36);
            this.btnRemove.TabIndex = 34;
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // dropdownListPost
            // 
            this.dropdownListPost.BackColor = System.Drawing.Color.Transparent;
            this.dropdownListPost.BorderRadius = 3;
            this.dropdownListPost.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dropdownListPost.ForeColor = System.Drawing.Color.Silver;
            this.dropdownListPost.Items = new string[0];
            this.dropdownListPost.Location = new System.Drawing.Point(285, 188);
            this.dropdownListPost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dropdownListPost.Name = "dropdownListPost";
            this.dropdownListPost.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.dropdownListPost.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(69)))), ((int)(((byte)(136)))));
            this.dropdownListPost.selectedIndex = -1;
            this.dropdownListPost.Size = new System.Drawing.Size(253, 27);
            this.dropdownListPost.TabIndex = 33;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(282, 11);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(78, 16);
            this.bunifuCustomLabel4.TabIndex = 32;
            this.bunifuCustomLabel4.Text = "Access Token";
            // 
            // bunifuSeparator15
            // 
            this.bunifuSeparator15.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator15.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator15.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator15.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator15.LineThickness = 1;
            this.bunifuSeparator15.Location = new System.Drawing.Point(267, 69);
            this.bunifuSeparator15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator15.Name = "bunifuSeparator15";
            this.bunifuSeparator15.Size = new System.Drawing.Size(656, 15);
            this.bunifuSeparator15.TabIndex = 29;
            this.bunifuSeparator15.Transparency = 255;
            this.bunifuSeparator15.Vertical = false;
            // 
            // bunifuSeparator14
            // 
            this.bunifuSeparator14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator14.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator14.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator14.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator14.LineThickness = 1;
            this.bunifuSeparator14.Location = new System.Drawing.Point(267, 11);
            this.bunifuSeparator14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator14.Name = "bunifuSeparator14";
            this.bunifuSeparator14.Size = new System.Drawing.Size(656, 15);
            this.bunifuSeparator14.TabIndex = 28;
            this.bunifuSeparator14.Transparency = 255;
            this.bunifuSeparator14.Vertical = false;
            // 
            // btnRemoveAll
            // 
            this.btnRemoveAll.ActiveBorderThickness = 1;
            this.btnRemoveAll.ActiveCornerRadius = 20;
            this.btnRemoveAll.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnRemoveAll.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnRemoveAll.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnRemoveAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnRemoveAll.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRemoveAll.BackgroundImage")));
            this.btnRemoveAll.ButtonText = "Remove All";
            this.btnRemoveAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveAll.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveAll.ForeColor = System.Drawing.Color.Silver;
            this.btnRemoveAll.IdleBorderThickness = 1;
            this.btnRemoveAll.IdleCornerRadius = 20;
            this.btnRemoveAll.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnRemoveAll.IdleForecolor = System.Drawing.Color.Silver;
            this.btnRemoveAll.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnRemoveAll.Location = new System.Drawing.Point(830, 121);
            this.btnRemoveAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRemoveAll.Name = "btnRemoveAll";
            this.btnRemoveAll.Size = new System.Drawing.Size(97, 36);
            this.btnRemoveAll.TabIndex = 3;
            this.btnRemoveAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRemoveAll.Click += new System.EventHandler(this.btnRemoveAll_Click);
            // 
            // btnGetAccess
            // 
            this.btnGetAccess.ActiveBorderThickness = 1;
            this.btnGetAccess.ActiveCornerRadius = 20;
            this.btnGetAccess.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnGetAccess.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnGetAccess.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnGetAccess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnGetAccess.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGetAccess.BackgroundImage")));
            this.btnGetAccess.ButtonText = "Get Access";
            this.btnGetAccess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetAccess.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetAccess.ForeColor = System.Drawing.Color.Silver;
            this.btnGetAccess.IdleBorderThickness = 1;
            this.btnGetAccess.IdleCornerRadius = 20;
            this.btnGetAccess.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnGetAccess.IdleForecolor = System.Drawing.Color.Silver;
            this.btnGetAccess.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnGetAccess.Location = new System.Drawing.Point(809, 28);
            this.btnGetAccess.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnGetAccess.Name = "btnGetAccess";
            this.btnGetAccess.Size = new System.Drawing.Size(103, 36);
            this.btnGetAccess.TabIndex = 2;
            this.btnGetAccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGetAccess.Click += new System.EventHandler(this.btnGetAccess_Click);
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(282, 89);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(101, 16);
            this.bunifuCustomLabel3.TabIndex = 27;
            this.bunifuCustomLabel3.Text = "Post Limit Amount";
            // 
            // bunifuSeparator11
            // 
            this.bunifuSeparator11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator11.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator11.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator11.LineThickness = 1;
            this.bunifuSeparator11.Location = new System.Drawing.Point(267, 149);
            this.bunifuSeparator11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator11.Name = "bunifuSeparator11";
            this.bunifuSeparator11.Size = new System.Drawing.Size(557, 15);
            this.bunifuSeparator11.TabIndex = 24;
            this.bunifuSeparator11.Transparency = 255;
            this.bunifuSeparator11.Vertical = false;
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator6.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(269, 239);
            this.bunifuSeparator6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator6.TabIndex = 18;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // bunifuSeparator10
            // 
            this.bunifuSeparator10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator10.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator10.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator10.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator10.LineThickness = 1;
            this.bunifuSeparator10.Location = new System.Drawing.Point(267, 86);
            this.bunifuSeparator10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator10.Name = "bunifuSeparator10";
            this.bunifuSeparator10.Size = new System.Drawing.Size(557, 15);
            this.bunifuSeparator10.TabIndex = 23;
            this.bunifuSeparator10.Transparency = 255;
            this.bunifuSeparator10.Vertical = false;
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator7.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator7.LineThickness = 1;
            this.bunifuSeparator7.Location = new System.Drawing.Point(269, 477);
            this.bunifuSeparator7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator7.TabIndex = 19;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(282, 238);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(120, 16);
            this.bunifuCustomLabel2.TabIndex = 22;
            this.bunifuCustomLabel2.Text = "Post Wall Information";
            // 
            // bunifuSeparator12
            // 
            this.bunifuSeparator12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator12.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator12.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator12.LineThickness = 1;
            this.bunifuSeparator12.Location = new System.Drawing.Point(261, 93);
            this.bunifuSeparator12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator12.Name = "bunifuSeparator12";
            this.bunifuSeparator12.Size = new System.Drawing.Size(10, 64);
            this.bunifuSeparator12.TabIndex = 25;
            this.bunifuSeparator12.Transparency = 255;
            this.bunifuSeparator12.Vertical = true;
            // 
            // bunifuSeparator16
            // 
            this.bunifuSeparator16.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator16.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator16.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator16.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator16.LineThickness = 1;
            this.bunifuSeparator16.Location = new System.Drawing.Point(261, 18);
            this.bunifuSeparator16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator16.Name = "bunifuSeparator16";
            this.bunifuSeparator16.Size = new System.Drawing.Size(10, 59);
            this.bunifuSeparator16.TabIndex = 30;
            this.bunifuSeparator16.Transparency = 255;
            this.bunifuSeparator16.Vertical = true;
            // 
            // bunifuSeparator17
            // 
            this.bunifuSeparator17.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator17.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator17.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator17.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator17.LineThickness = 1;
            this.bunifuSeparator17.Location = new System.Drawing.Point(918, 18);
            this.bunifuSeparator17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator17.Name = "bunifuSeparator17";
            this.bunifuSeparator17.Size = new System.Drawing.Size(10, 59);
            this.bunifuSeparator17.TabIndex = 31;
            this.bunifuSeparator17.Transparency = 255;
            this.bunifuSeparator17.Vertical = true;
            // 
            // bunifuSeparator13
            // 
            this.bunifuSeparator13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator13.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator13.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator13.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator13.LineThickness = 1;
            this.bunifuSeparator13.Location = new System.Drawing.Point(819, 93);
            this.bunifuSeparator13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator13.Name = "bunifuSeparator13";
            this.bunifuSeparator13.Size = new System.Drawing.Size(10, 64);
            this.bunifuSeparator13.TabIndex = 26;
            this.bunifuSeparator13.Transparency = 255;
            this.bunifuSeparator13.Vertical = true;
            // 
            // bunifuSeparator21
            // 
            this.bunifuSeparator21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator21.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator21.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator21.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator21.LineThickness = 1;
            this.bunifuSeparator21.Location = new System.Drawing.Point(667, 172);
            this.bunifuSeparator21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator21.Name = "bunifuSeparator21";
            this.bunifuSeparator21.Size = new System.Drawing.Size(10, 55);
            this.bunifuSeparator21.TabIndex = 39;
            this.bunifuSeparator21.Transparency = 255;
            this.bunifuSeparator21.Vertical = true;
            // 
            // bunifuSeparator9
            // 
            this.bunifuSeparator9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator9.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator9.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator9.LineThickness = 1;
            this.bunifuSeparator9.Location = new System.Drawing.Point(906, 246);
            this.bunifuSeparator9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator9.Name = "bunifuSeparator9";
            this.bunifuSeparator9.Size = new System.Drawing.Size(22, 239);
            this.bunifuSeparator9.TabIndex = 21;
            this.bunifuSeparator9.Transparency = 255;
            this.bunifuSeparator9.Vertical = true;
            // 
            // bunifuSeparator8
            // 
            this.bunifuSeparator8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator8.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator8.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator8.LineThickness = 1;
            this.bunifuSeparator8.Location = new System.Drawing.Point(257, 246);
            this.bunifuSeparator8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator8.Name = "bunifuSeparator8";
            this.bunifuSeparator8.Size = new System.Drawing.Size(22, 239);
            this.bunifuSeparator8.TabIndex = 20;
            this.bunifuSeparator8.Transparency = 255;
            this.bunifuSeparator8.Vertical = true;
            // 
            // bunifuSeparator52
            // 
            this.bunifuSeparator52.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator52.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator52.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator52.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator52.LineThickness = 1;
            this.bunifuSeparator52.Location = new System.Drawing.Point(261, 500);
            this.bunifuSeparator52.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator52.Name = "bunifuSeparator52";
            this.bunifuSeparator52.Size = new System.Drawing.Size(10, 66);
            this.bunifuSeparator52.TabIndex = 44;
            this.bunifuSeparator52.Transparency = 255;
            this.bunifuSeparator52.Vertical = true;
            // 
            // bunifuSeparator54
            // 
            this.bunifuSeparator54.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator54.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator54.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator54.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator54.LineThickness = 1;
            this.bunifuSeparator54.Location = new System.Drawing.Point(912, 500);
            this.bunifuSeparator54.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator54.Name = "bunifuSeparator54";
            this.bunifuSeparator54.Size = new System.Drawing.Size(10, 66);
            this.bunifuSeparator54.TabIndex = 46;
            this.bunifuSeparator54.Transparency = 255;
            this.bunifuSeparator54.Vertical = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel14);
            this.tabPage2.Controls.Add(this.bunifuSeparator55);
            this.tabPage2.Controls.Add(this.bunifuSeparator56);
            this.tabPage2.Controls.Add(this.bunifuSeparator57);
            this.tabPage2.Controls.Add(this.bunifuSeparator58);
            this.tabPage2.Controls.Add(this.bunifuSeparator34);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel12);
            this.tabPage2.Controls.Add(this.listView2);
            this.tabPage2.Controls.Add(this.bunifuSeparator46);
            this.tabPage2.Controls.Add(this.bunifuSeparator47);
            this.tabPage2.Controls.Add(this.btnPost);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel11);
            this.tabPage2.Controls.Add(this.bunifuSeparator43);
            this.tabPage2.Controls.Add(this.bunifuSeparator42);
            this.tabPage2.Controls.Add(this.btnOKPostType);
            this.tabPage2.Controls.Add(this.dropdownPostType);
            this.tabPage2.Controls.Add(this.btnSelectAll);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel10);
            this.tabPage2.Controls.Add(this.bunifuSeparator38);
            this.tabPage2.Controls.Add(this.bunifuSeparator39);
            this.tabPage2.Controls.Add(this.txtAmountGroups);
            this.tabPage2.Controls.Add(this.GroupsSlider);
            this.tabPage2.Controls.Add(this.bunifuSeparator40);
            this.tabPage2.Controls.Add(this.bunifuSeparator41);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel9);
            this.tabPage2.Controls.Add(this.bunifuSeparator35);
            this.tabPage2.Controls.Add(this.btnAddGroup);
            this.tabPage2.Controls.Add(this.dropdownGroupList);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel8);
            this.tabPage2.Controls.Add(this.bunifuSeparator30);
            this.tabPage2.Controls.Add(this.bunifuSeparator33);
            this.tabPage2.Controls.Add(this.bunifuSeparator32);
            this.tabPage2.Controls.Add(this.bunifuSeparator31);
            this.tabPage2.Controls.Add(this.txtMessage);
            this.tabPage2.Controls.Add(this.progressBar2);
            this.tabPage2.Controls.Add(this.bunifuSeparator26);
            this.tabPage2.Controls.Add(this.bunifuSeparator27);
            this.tabPage2.Controls.Add(this.bunifuSeparator28);
            this.tabPage2.Controls.Add(this.bunifuSeparator29);
            this.tabPage2.Controls.Add(this.txtToken2);
            this.tabPage2.Controls.Add(this.bunifuCustomLabel6);
            this.tabPage2.Controls.Add(this.bunifuSeparator22);
            this.tabPage2.Controls.Add(this.bunifuSeparator23);
            this.tabPage2.Controls.Add(this.btnGetAccessToken2);
            this.tabPage2.Controls.Add(this.bunifuSeparator25);
            this.tabPage2.Controls.Add(this.bunifuSeparator24);
            this.tabPage2.Controls.Add(this.bunifuSeparator37);
            this.tabPage2.Controls.Add(this.bunifuSeparator44);
            this.tabPage2.Controls.Add(this.bunifuSeparator45);
            this.tabPage2.Controls.Add(this.bunifuSeparator50);
            this.tabPage2.Controls.Add(this.bunifuSeparator49);
            this.tabPage2.Controls.Add(this.bunifuSeparator36);
            this.tabPage2.Controls.Add(this.bunifuSeparator48);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(942, 573);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Post Memory";
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.listBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox2.ForeColor = System.Drawing.Color.Silver;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(290, 507);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(618, 50);
            this.listBox2.TabIndex = 84;
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(290, 488);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(30, 16);
            this.bunifuCustomLabel14.TabIndex = 89;
            this.bunifuCustomLabel14.Text = "Log ";
            // 
            // bunifuSeparator55
            // 
            this.bunifuSeparator55.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator55.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator55.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator55.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator55.LineThickness = 1;
            this.bunifuSeparator55.Location = new System.Drawing.Point(275, 557);
            this.bunifuSeparator55.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator55.Name = "bunifuSeparator55";
            this.bunifuSeparator55.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator55.TabIndex = 87;
            this.bunifuSeparator55.Transparency = 255;
            this.bunifuSeparator55.Vertical = false;
            // 
            // bunifuSeparator56
            // 
            this.bunifuSeparator56.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator56.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator56.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator56.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator56.LineThickness = 1;
            this.bunifuSeparator56.Location = new System.Drawing.Point(275, 492);
            this.bunifuSeparator56.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator56.Name = "bunifuSeparator56";
            this.bunifuSeparator56.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator56.TabIndex = 85;
            this.bunifuSeparator56.Transparency = 255;
            this.bunifuSeparator56.Vertical = false;
            // 
            // bunifuSeparator57
            // 
            this.bunifuSeparator57.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator57.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator57.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator57.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator57.LineThickness = 1;
            this.bunifuSeparator57.Location = new System.Drawing.Point(269, 499);
            this.bunifuSeparator57.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator57.Name = "bunifuSeparator57";
            this.bunifuSeparator57.Size = new System.Drawing.Size(10, 66);
            this.bunifuSeparator57.TabIndex = 86;
            this.bunifuSeparator57.Transparency = 255;
            this.bunifuSeparator57.Vertical = true;
            // 
            // bunifuSeparator58
            // 
            this.bunifuSeparator58.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator58.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator58.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator58.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator58.LineThickness = 1;
            this.bunifuSeparator58.Location = new System.Drawing.Point(918, 499);
            this.bunifuSeparator58.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator58.Name = "bunifuSeparator58";
            this.bunifuSeparator58.Size = new System.Drawing.Size(10, 66);
            this.bunifuSeparator58.TabIndex = 88;
            this.bunifuSeparator58.Transparency = 255;
            this.bunifuSeparator58.Vertical = true;
            // 
            // bunifuSeparator34
            // 
            this.bunifuSeparator34.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator34.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator34.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator34.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator34.LineThickness = 1;
            this.bunifuSeparator34.Location = new System.Drawing.Point(274, 136);
            this.bunifuSeparator34.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator34.Name = "bunifuSeparator34";
            this.bunifuSeparator34.Size = new System.Drawing.Size(478, 15);
            this.bunifuSeparator34.TabIndex = 56;
            this.bunifuSeparator34.Transparency = 255;
            this.bunifuSeparator34.Vertical = false;
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(296, 346);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(65, 16);
            this.bunifuCustomLabel12.TabIndex = 81;
            this.bunifuCustomLabel12.Text = "Groups List";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.listView2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.ForeColor = System.Drawing.Color.Silver;
            this.listView2.Location = new System.Drawing.Point(291, 368);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(615, 104);
            this.listView2.TabIndex = 76;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            this.listView2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView2_MouseClick);
            // 
            // bunifuSeparator46
            // 
            this.bunifuSeparator46.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator46.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator46.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator46.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator46.LineThickness = 1;
            this.bunifuSeparator46.Location = new System.Drawing.Point(275, 347);
            this.bunifuSeparator46.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator46.Name = "bunifuSeparator46";
            this.bunifuSeparator46.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator46.TabIndex = 77;
            this.bunifuSeparator46.Transparency = 255;
            this.bunifuSeparator46.Vertical = false;
            // 
            // bunifuSeparator47
            // 
            this.bunifuSeparator47.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator47.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator47.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator47.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator47.LineThickness = 1;
            this.bunifuSeparator47.Location = new System.Drawing.Point(278, 610);
            this.bunifuSeparator47.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator47.Name = "bunifuSeparator47";
            this.bunifuSeparator47.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator47.TabIndex = 78;
            this.bunifuSeparator47.Transparency = 255;
            this.bunifuSeparator47.Vertical = false;
            // 
            // btnPost
            // 
            this.btnPost.ActiveBorderThickness = 1;
            this.btnPost.ActiveCornerRadius = 20;
            this.btnPost.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnPost.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnPost.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnPost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnPost.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPost.BackgroundImage")));
            this.btnPost.ButtonText = "Post";
            this.btnPost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPost.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPost.ForeColor = System.Drawing.Color.Silver;
            this.btnPost.IdleBorderThickness = 1;
            this.btnPost.IdleCornerRadius = 20;
            this.btnPost.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnPost.IdleForecolor = System.Drawing.Color.Silver;
            this.btnPost.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnPost.Location = new System.Drawing.Point(837, 270);
            this.btnPost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(79, 71);
            this.btnPost.TabIndex = 75;
            this.btnPost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPost.Click += new System.EventHandler(this.btnPost_Click);
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(773, 81);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(59, 16);
            this.bunifuCustomLabel11.TabIndex = 74;
            this.bunifuCustomLabel11.Text = "Post Type";
            // 
            // bunifuSeparator43
            // 
            this.bunifuSeparator43.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator43.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator43.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator43.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator43.LineThickness = 1;
            this.bunifuSeparator43.Location = new System.Drawing.Point(763, 135);
            this.bunifuSeparator43.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator43.Name = "bunifuSeparator43";
            this.bunifuSeparator43.Size = new System.Drawing.Size(159, 15);
            this.bunifuSeparator43.TabIndex = 71;
            this.bunifuSeparator43.Transparency = 255;
            this.bunifuSeparator43.Vertical = false;
            // 
            // bunifuSeparator42
            // 
            this.bunifuSeparator42.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator42.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator42.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator42.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator42.LineThickness = 1;
            this.bunifuSeparator42.Location = new System.Drawing.Point(763, 82);
            this.bunifuSeparator42.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator42.Name = "bunifuSeparator42";
            this.bunifuSeparator42.Size = new System.Drawing.Size(159, 15);
            this.bunifuSeparator42.TabIndex = 70;
            this.bunifuSeparator42.Transparency = 255;
            this.bunifuSeparator42.Vertical = false;
            // 
            // btnOKPostType
            // 
            this.btnOKPostType.ActiveBorderThickness = 1;
            this.btnOKPostType.ActiveCornerRadius = 20;
            this.btnOKPostType.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnOKPostType.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnOKPostType.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnOKPostType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnOKPostType.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOKPostType.BackgroundImage")));
            this.btnOKPostType.ButtonText = "OK";
            this.btnOKPostType.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOKPostType.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOKPostType.ForeColor = System.Drawing.Color.Silver;
            this.btnOKPostType.IdleBorderThickness = 1;
            this.btnOKPostType.IdleCornerRadius = 20;
            this.btnOKPostType.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnOKPostType.IdleForecolor = System.Drawing.Color.Silver;
            this.btnOKPostType.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnOKPostType.Location = new System.Drawing.Point(859, 101);
            this.btnOKPostType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnOKPostType.Name = "btnOKPostType";
            this.btnOKPostType.Size = new System.Drawing.Size(52, 34);
            this.btnOKPostType.TabIndex = 69;
            this.btnOKPostType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOKPostType.Click += new System.EventHandler(this.btnOKPostType_Click);
            // 
            // dropdownPostType
            // 
            this.dropdownPostType.BackColor = System.Drawing.Color.Transparent;
            this.dropdownPostType.BorderRadius = 3;
            this.dropdownPostType.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dropdownPostType.ForeColor = System.Drawing.Color.Silver;
            this.dropdownPostType.Items = new string[] {
        "Profile",
        "Groups"};
            this.dropdownPostType.Location = new System.Drawing.Point(767, 105);
            this.dropdownPostType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dropdownPostType.Name = "dropdownPostType";
            this.dropdownPostType.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.dropdownPostType.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(69)))), ((int)(((byte)(136)))));
            this.dropdownPostType.selectedIndex = -1;
            this.dropdownPostType.Size = new System.Drawing.Size(90, 27);
            this.dropdownPostType.TabIndex = 68;
            this.dropdownPostType.onItemSelected += new System.EventHandler(this.dropdownPostType_onItemSelected);
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.ActiveBorderThickness = 1;
            this.btnSelectAll.ActiveCornerRadius = 20;
            this.btnSelectAll.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnSelectAll.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSelectAll.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnSelectAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnSelectAll.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSelectAll.BackgroundImage")));
            this.btnSelectAll.ButtonText = "Select All";
            this.btnSelectAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectAll.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectAll.ForeColor = System.Drawing.Color.Silver;
            this.btnSelectAll.IdleBorderThickness = 1;
            this.btnSelectAll.IdleCornerRadius = 20;
            this.btnSelectAll.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnSelectAll.IdleForecolor = System.Drawing.Color.Silver;
            this.btnSelectAll.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnSelectAll.Location = new System.Drawing.Point(645, 99);
            this.btnSelectAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(97, 36);
            this.btnSelectAll.TabIndex = 67;
            this.btnSelectAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(289, 270);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(118, 16);
            this.bunifuCustomLabel10.TabIndex = 66;
            this.bunifuCustomLabel10.Text = "Groups Limit Amount";
            // 
            // bunifuSeparator38
            // 
            this.bunifuSeparator38.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator38.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator38.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator38.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator38.LineThickness = 1;
            this.bunifuSeparator38.Location = new System.Drawing.Point(274, 330);
            this.bunifuSeparator38.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator38.Name = "bunifuSeparator38";
            this.bunifuSeparator38.Size = new System.Drawing.Size(557, 15);
            this.bunifuSeparator38.TabIndex = 63;
            this.bunifuSeparator38.Transparency = 255;
            this.bunifuSeparator38.Vertical = false;
            // 
            // bunifuSeparator39
            // 
            this.bunifuSeparator39.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator39.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator39.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator39.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator39.LineThickness = 1;
            this.bunifuSeparator39.Location = new System.Drawing.Point(274, 267);
            this.bunifuSeparator39.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator39.Name = "bunifuSeparator39";
            this.bunifuSeparator39.Size = new System.Drawing.Size(557, 15);
            this.bunifuSeparator39.TabIndex = 62;
            this.bunifuSeparator39.Transparency = 255;
            this.bunifuSeparator39.Vertical = false;
            // 
            // txtAmountGroups
            // 
            this.txtAmountGroups.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAmountGroups.Enabled = false;
            this.txtAmountGroups.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtAmountGroups.ForeColor = System.Drawing.Color.Silver;
            this.txtAmountGroups.HintForeColor = System.Drawing.Color.Silver;
            this.txtAmountGroups.HintText = "";
            this.txtAmountGroups.isPassword = false;
            this.txtAmountGroups.LineFocusedColor = System.Drawing.Color.Silver;
            this.txtAmountGroups.LineIdleColor = System.Drawing.Color.Silver;
            this.txtAmountGroups.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtAmountGroups.LineThickness = 3;
            this.txtAmountGroups.Location = new System.Drawing.Point(770, 289);
            this.txtAmountGroups.Margin = new System.Windows.Forms.Padding(4);
            this.txtAmountGroups.Name = "txtAmountGroups";
            this.txtAmountGroups.Size = new System.Drawing.Size(51, 33);
            this.txtAmountGroups.TabIndex = 60;
            this.txtAmountGroups.Text = "0";
            this.txtAmountGroups.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GroupsSlider
            // 
            this.GroupsSlider.BackColor = System.Drawing.Color.Transparent;
            this.GroupsSlider.BackgroudColor = System.Drawing.Color.Silver;
            this.GroupsSlider.BorderRadius = 0;
            this.GroupsSlider.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.GroupsSlider.Location = new System.Drawing.Point(281, 289);
            this.GroupsSlider.MaximumValue = 500;
            this.GroupsSlider.Name = "GroupsSlider";
            this.GroupsSlider.Size = new System.Drawing.Size(482, 30);
            this.GroupsSlider.TabIndex = 61;
            this.GroupsSlider.Value = 0;
            this.GroupsSlider.ValueChanged += new System.EventHandler(this.GroupsSlider_ValueChanged);
            // 
            // bunifuSeparator40
            // 
            this.bunifuSeparator40.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator40.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator40.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator40.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator40.LineThickness = 1;
            this.bunifuSeparator40.Location = new System.Drawing.Point(268, 274);
            this.bunifuSeparator40.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator40.Name = "bunifuSeparator40";
            this.bunifuSeparator40.Size = new System.Drawing.Size(10, 64);
            this.bunifuSeparator40.TabIndex = 64;
            this.bunifuSeparator40.Transparency = 255;
            this.bunifuSeparator40.Vertical = true;
            // 
            // bunifuSeparator41
            // 
            this.bunifuSeparator41.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator41.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator41.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator41.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator41.LineThickness = 1;
            this.bunifuSeparator41.Location = new System.Drawing.Point(826, 274);
            this.bunifuSeparator41.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator41.Name = "bunifuSeparator41";
            this.bunifuSeparator41.Size = new System.Drawing.Size(10, 64);
            this.bunifuSeparator41.TabIndex = 65;
            this.bunifuSeparator41.Transparency = 255;
            this.bunifuSeparator41.Vertical = true;
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(280, 81);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(168, 16);
            this.bunifuCustomLabel9.TabIndex = 59;
            this.bunifuCustomLabel9.Text = "Multiple Group Post (Manual)";
            // 
            // bunifuSeparator35
            // 
            this.bunifuSeparator35.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator35.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator35.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator35.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator35.LineThickness = 1;
            this.bunifuSeparator35.Location = new System.Drawing.Point(274, 82);
            this.bunifuSeparator35.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator35.Name = "bunifuSeparator35";
            this.bunifuSeparator35.Size = new System.Drawing.Size(478, 15);
            this.bunifuSeparator35.TabIndex = 55;
            this.bunifuSeparator35.Transparency = 255;
            this.bunifuSeparator35.Vertical = false;
            // 
            // btnAddGroup
            // 
            this.btnAddGroup.ActiveBorderThickness = 1;
            this.btnAddGroup.ActiveCornerRadius = 20;
            this.btnAddGroup.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnAddGroup.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnAddGroup.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnAddGroup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnAddGroup.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddGroup.BackgroundImage")));
            this.btnAddGroup.ButtonText = "Add";
            this.btnAddGroup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddGroup.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGroup.ForeColor = System.Drawing.Color.Silver;
            this.btnAddGroup.IdleBorderThickness = 1;
            this.btnAddGroup.IdleCornerRadius = 20;
            this.btnAddGroup.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnAddGroup.IdleForecolor = System.Drawing.Color.Silver;
            this.btnAddGroup.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnAddGroup.Location = new System.Drawing.Point(542, 99);
            this.btnAddGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddGroup.Name = "btnAddGroup";
            this.btnAddGroup.Size = new System.Drawing.Size(97, 36);
            this.btnAddGroup.TabIndex = 54;
            this.btnAddGroup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddGroup.Click += new System.EventHandler(this.btnAddGroup_Click);
            // 
            // dropdownGroupList
            // 
            this.dropdownGroupList.BackColor = System.Drawing.Color.Transparent;
            this.dropdownGroupList.BorderRadius = 3;
            this.dropdownGroupList.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dropdownGroupList.ForeColor = System.Drawing.Color.Silver;
            this.dropdownGroupList.Items = new string[0];
            this.dropdownGroupList.Location = new System.Drawing.Point(283, 105);
            this.dropdownGroupList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dropdownGroupList.Name = "dropdownGroupList";
            this.dropdownGroupList.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.dropdownGroupList.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(69)))), ((int)(((byte)(136)))));
            this.dropdownGroupList.selectedIndex = -1;
            this.dropdownGroupList.Size = new System.Drawing.Size(253, 27);
            this.dropdownGroupList.TabIndex = 53;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(295, 157);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(87, 16);
            this.bunifuCustomLabel8.TabIndex = 47;
            this.bunifuCustomLabel8.Text = "Update Status";
            // 
            // bunifuSeparator30
            // 
            this.bunifuSeparator30.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator30.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator30.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator30.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator30.LineThickness = 1;
            this.bunifuSeparator30.Location = new System.Drawing.Point(283, 168);
            this.bunifuSeparator30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator30.Name = "bunifuSeparator30";
            this.bunifuSeparator30.Size = new System.Drawing.Size(628, 10);
            this.bunifuSeparator30.TabIndex = 49;
            this.bunifuSeparator30.Transparency = 255;
            this.bunifuSeparator30.Vertical = false;
            // 
            // bunifuSeparator33
            // 
            this.bunifuSeparator33.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator33.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator33.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator33.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator33.LineThickness = 1;
            this.bunifuSeparator33.Location = new System.Drawing.Point(906, 173);
            this.bunifuSeparator33.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator33.Name = "bunifuSeparator33";
            this.bunifuSeparator33.Size = new System.Drawing.Size(10, 60);
            this.bunifuSeparator33.TabIndex = 52;
            this.bunifuSeparator33.Transparency = 255;
            this.bunifuSeparator33.Vertical = true;
            // 
            // bunifuSeparator32
            // 
            this.bunifuSeparator32.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator32.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator32.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator32.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator32.LineThickness = 1;
            this.bunifuSeparator32.Location = new System.Drawing.Point(277, 173);
            this.bunifuSeparator32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator32.Name = "bunifuSeparator32";
            this.bunifuSeparator32.Size = new System.Drawing.Size(10, 60);
            this.bunifuSeparator32.TabIndex = 51;
            this.bunifuSeparator32.Transparency = 255;
            this.bunifuSeparator32.Vertical = true;
            // 
            // bunifuSeparator31
            // 
            this.bunifuSeparator31.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator31.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator31.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator31.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator31.LineThickness = 1;
            this.bunifuSeparator31.Location = new System.Drawing.Point(283, 228);
            this.bunifuSeparator31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator31.Name = "bunifuSeparator31";
            this.bunifuSeparator31.Size = new System.Drawing.Size(628, 10);
            this.bunifuSeparator31.TabIndex = 50;
            this.bunifuSeparator31.Transparency = 255;
            this.bunifuSeparator31.Vertical = false;
            // 
            // txtMessage
            // 
            this.txtMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.txtMessage.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.txtMessage.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMessage.ForeColor = System.Drawing.Color.Silver;
            this.txtMessage.Location = new System.Drawing.Point(284, 176);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(627, 55);
            this.txtMessage.TabIndex = 1;
            // 
            // progressBar2
            // 
            this.progressBar2.BackColor = System.Drawing.Color.Silver;
            this.progressBar2.BorderRadius = 5;
            this.progressBar2.Location = new System.Drawing.Point(290, 241);
            this.progressBar2.MaximumValue = 100;
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.progressBar2.Size = new System.Drawing.Size(615, 8);
            this.progressBar2.TabIndex = 42;
            this.progressBar2.Value = 0;
            // 
            // bunifuSeparator26
            // 
            this.bunifuSeparator26.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator26.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator26.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator26.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator26.LineThickness = 1;
            this.bunifuSeparator26.Location = new System.Drawing.Point(274, 158);
            this.bunifuSeparator26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator26.Name = "bunifuSeparator26";
            this.bunifuSeparator26.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator26.TabIndex = 43;
            this.bunifuSeparator26.Transparency = 255;
            this.bunifuSeparator26.Vertical = false;
            // 
            // bunifuSeparator27
            // 
            this.bunifuSeparator27.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator27.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator27.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator27.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator27.LineThickness = 1;
            this.bunifuSeparator27.Location = new System.Drawing.Point(274, 251);
            this.bunifuSeparator27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator27.Name = "bunifuSeparator27";
            this.bunifuSeparator27.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator27.TabIndex = 44;
            this.bunifuSeparator27.Transparency = 255;
            this.bunifuSeparator27.Vertical = false;
            // 
            // bunifuSeparator28
            // 
            this.bunifuSeparator28.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator28.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator28.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator28.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator28.LineThickness = 1;
            this.bunifuSeparator28.Location = new System.Drawing.Point(911, 165);
            this.bunifuSeparator28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator28.Name = "bunifuSeparator28";
            this.bunifuSeparator28.Size = new System.Drawing.Size(22, 94);
            this.bunifuSeparator28.TabIndex = 46;
            this.bunifuSeparator28.Transparency = 255;
            this.bunifuSeparator28.Vertical = true;
            // 
            // bunifuSeparator29
            // 
            this.bunifuSeparator29.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator29.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator29.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator29.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator29.LineThickness = 1;
            this.bunifuSeparator29.Location = new System.Drawing.Point(262, 165);
            this.bunifuSeparator29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator29.Name = "bunifuSeparator29";
            this.bunifuSeparator29.Size = new System.Drawing.Size(22, 94);
            this.bunifuSeparator29.TabIndex = 45;
            this.bunifuSeparator29.Transparency = 255;
            this.bunifuSeparator29.Vertical = true;
            // 
            // txtToken2
            // 
            this.txtToken2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtToken2.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtToken2.ForeColor = System.Drawing.Color.Silver;
            this.txtToken2.HintForeColor = System.Drawing.Color.Silver;
            this.txtToken2.HintText = "Your Facebook Access Token";
            this.txtToken2.isPassword = false;
            this.txtToken2.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtToken2.LineIdleColor = System.Drawing.Color.Silver;
            this.txtToken2.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtToken2.LineThickness = 3;
            this.txtToken2.Location = new System.Drawing.Point(284, 28);
            this.txtToken2.Margin = new System.Windows.Forms.Padding(4);
            this.txtToken2.Name = "txtToken2";
            this.txtToken2.Size = new System.Drawing.Size(514, 33);
            this.txtToken2.TabIndex = 0;
            this.txtToken2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(281, 11);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(78, 16);
            this.bunifuCustomLabel6.TabIndex = 39;
            this.bunifuCustomLabel6.Text = "Access Token";
            // 
            // bunifuSeparator22
            // 
            this.bunifuSeparator22.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator22.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator22.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator22.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator22.LineThickness = 1;
            this.bunifuSeparator22.Location = new System.Drawing.Point(274, 69);
            this.bunifuSeparator22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator22.Name = "bunifuSeparator22";
            this.bunifuSeparator22.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator22.TabIndex = 36;
            this.bunifuSeparator22.Transparency = 255;
            this.bunifuSeparator22.Vertical = false;
            // 
            // bunifuSeparator23
            // 
            this.bunifuSeparator23.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator23.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator23.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator23.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator23.LineThickness = 1;
            this.bunifuSeparator23.Location = new System.Drawing.Point(274, 11);
            this.bunifuSeparator23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator23.Name = "bunifuSeparator23";
            this.bunifuSeparator23.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator23.TabIndex = 35;
            this.bunifuSeparator23.Transparency = 255;
            this.bunifuSeparator23.Vertical = false;
            // 
            // btnGetAccessToken2
            // 
            this.btnGetAccessToken2.ActiveBorderThickness = 1;
            this.btnGetAccessToken2.ActiveCornerRadius = 20;
            this.btnGetAccessToken2.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnGetAccessToken2.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnGetAccessToken2.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnGetAccessToken2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnGetAccessToken2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGetAccessToken2.BackgroundImage")));
            this.btnGetAccessToken2.ButtonText = "Get Access";
            this.btnGetAccessToken2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetAccessToken2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetAccessToken2.ForeColor = System.Drawing.Color.Silver;
            this.btnGetAccessToken2.IdleBorderThickness = 1;
            this.btnGetAccessToken2.IdleCornerRadius = 20;
            this.btnGetAccessToken2.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnGetAccessToken2.IdleForecolor = System.Drawing.Color.Silver;
            this.btnGetAccessToken2.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnGetAccessToken2.Location = new System.Drawing.Point(808, 28);
            this.btnGetAccessToken2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnGetAccessToken2.Name = "btnGetAccessToken2";
            this.btnGetAccessToken2.Size = new System.Drawing.Size(103, 36);
            this.btnGetAccessToken2.TabIndex = 34;
            this.btnGetAccessToken2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGetAccessToken2.Click += new System.EventHandler(this.btnGetAccessToken2_Click);
            // 
            // bunifuSeparator25
            // 
            this.bunifuSeparator25.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator25.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator25.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator25.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator25.LineThickness = 1;
            this.bunifuSeparator25.Location = new System.Drawing.Point(917, 18);
            this.bunifuSeparator25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator25.Name = "bunifuSeparator25";
            this.bunifuSeparator25.Size = new System.Drawing.Size(10, 59);
            this.bunifuSeparator25.TabIndex = 38;
            this.bunifuSeparator25.Transparency = 255;
            this.bunifuSeparator25.Vertical = true;
            // 
            // bunifuSeparator24
            // 
            this.bunifuSeparator24.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator24.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator24.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator24.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator24.LineThickness = 1;
            this.bunifuSeparator24.Location = new System.Drawing.Point(268, 18);
            this.bunifuSeparator24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator24.Name = "bunifuSeparator24";
            this.bunifuSeparator24.Size = new System.Drawing.Size(10, 59);
            this.bunifuSeparator24.TabIndex = 37;
            this.bunifuSeparator24.Transparency = 255;
            this.bunifuSeparator24.Vertical = true;
            // 
            // bunifuSeparator37
            // 
            this.bunifuSeparator37.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator37.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator37.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator37.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator37.LineThickness = 1;
            this.bunifuSeparator37.Location = new System.Drawing.Point(747, 89);
            this.bunifuSeparator37.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator37.Name = "bunifuSeparator37";
            this.bunifuSeparator37.Size = new System.Drawing.Size(10, 55);
            this.bunifuSeparator37.TabIndex = 58;
            this.bunifuSeparator37.Transparency = 255;
            this.bunifuSeparator37.Vertical = true;
            // 
            // bunifuSeparator44
            // 
            this.bunifuSeparator44.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator44.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator44.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator44.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator44.LineThickness = 1;
            this.bunifuSeparator44.Location = new System.Drawing.Point(757, 89);
            this.bunifuSeparator44.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator44.Name = "bunifuSeparator44";
            this.bunifuSeparator44.Size = new System.Drawing.Size(10, 54);
            this.bunifuSeparator44.TabIndex = 72;
            this.bunifuSeparator44.Transparency = 255;
            this.bunifuSeparator44.Vertical = true;
            // 
            // bunifuSeparator45
            // 
            this.bunifuSeparator45.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator45.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator45.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator45.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator45.LineThickness = 1;
            this.bunifuSeparator45.Location = new System.Drawing.Point(917, 89);
            this.bunifuSeparator45.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator45.Name = "bunifuSeparator45";
            this.bunifuSeparator45.Size = new System.Drawing.Size(10, 54);
            this.bunifuSeparator45.TabIndex = 73;
            this.bunifuSeparator45.Transparency = 255;
            this.bunifuSeparator45.Vertical = true;
            // 
            // bunifuSeparator50
            // 
            this.bunifuSeparator50.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator50.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator50.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator50.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator50.LineThickness = 1;
            this.bunifuSeparator50.Location = new System.Drawing.Point(276, 476);
            this.bunifuSeparator50.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator50.Name = "bunifuSeparator50";
            this.bunifuSeparator50.Size = new System.Drawing.Size(648, 15);
            this.bunifuSeparator50.TabIndex = 83;
            this.bunifuSeparator50.Transparency = 255;
            this.bunifuSeparator50.Vertical = false;
            // 
            // bunifuSeparator49
            // 
            this.bunifuSeparator49.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator49.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator49.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator49.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator49.LineThickness = 1;
            this.bunifuSeparator49.Location = new System.Drawing.Point(263, 354);
            this.bunifuSeparator49.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator49.Name = "bunifuSeparator49";
            this.bunifuSeparator49.Size = new System.Drawing.Size(22, 130);
            this.bunifuSeparator49.TabIndex = 79;
            this.bunifuSeparator49.Transparency = 255;
            this.bunifuSeparator49.Vertical = true;
            // 
            // bunifuSeparator36
            // 
            this.bunifuSeparator36.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator36.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator36.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator36.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator36.LineThickness = 1;
            this.bunifuSeparator36.Location = new System.Drawing.Point(268, 90);
            this.bunifuSeparator36.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator36.Name = "bunifuSeparator36";
            this.bunifuSeparator36.Size = new System.Drawing.Size(10, 53);
            this.bunifuSeparator36.TabIndex = 57;
            this.bunifuSeparator36.Transparency = 255;
            this.bunifuSeparator36.Vertical = true;
            // 
            // bunifuSeparator48
            // 
            this.bunifuSeparator48.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator48.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator48.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator48.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator48.LineThickness = 1;
            this.bunifuSeparator48.Location = new System.Drawing.Point(913, 354);
            this.bunifuSeparator48.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator48.Name = "bunifuSeparator48";
            this.bunifuSeparator48.Size = new System.Drawing.Size(22, 131);
            this.bunifuSeparator48.TabIndex = 82;
            this.bunifuSeparator48.Transparency = 255;
            this.bunifuSeparator48.Vertical = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.tabPage3.Controls.Add(this.bunifuCustomLabel20);
            this.tabPage3.Controls.Add(this.bunifuSeparator67);
            this.tabPage3.Controls.Add(this.bunifuSeparator65);
            this.tabPage3.Controls.Add(this.bunifuCustomLabel19);
            this.tabPage3.Controls.Add(this.bunifuSeparator64);
            this.tabPage3.Controls.Add(this.bunifuCustomLabel18);
            this.tabPage3.Controls.Add(this.bunifuSeparator60);
            this.tabPage3.Controls.Add(this.bunifuSeparator61);
            this.tabPage3.Controls.Add(this.bunifuSeparator62);
            this.tabPage3.Controls.Add(this.bunifuSeparator63);
            this.tabPage3.Controls.Add(this.Star5);
            this.tabPage3.Controls.Add(this.Star4);
            this.tabPage3.Controls.Add(this.Star3);
            this.tabPage3.Controls.Add(this.Star2);
            this.tabPage3.Controls.Add(this.Star1);
            this.tabPage3.Controls.Add(this.txtName);
            this.tabPage3.Controls.Add(this.bunifuCustomLabel17);
            this.tabPage3.Controls.Add(this.btnFeedback);
            this.tabPage3.Controls.Add(this.txtFeedbackMessage);
            this.tabPage3.Controls.Add(this.bunifuCustomLabel15);
            this.tabPage3.Controls.Add(this.txtSubject);
            this.tabPage3.Controls.Add(this.bunifuCustomLabel16);
            this.tabPage3.Controls.Add(this.bunifuSeparator66);
            this.tabPage3.Controls.Add(this.bunifuSeparator59);
            this.tabPage3.Controls.Add(this.bunifuSeparator68);
            this.tabPage3.Controls.Add(this.bunifuSeparator69);
            this.tabPage3.Controls.Add(this.bunifuSeparator70);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(942, 573);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Feedback";
            // 
            // bunifuCustomLabel20
            // 
            this.bunifuCustomLabel20.AutoSize = true;
            this.bunifuCustomLabel20.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel20.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel20.Location = new System.Drawing.Point(282, 12);
            this.bunifuCustomLabel20.Name = "bunifuCustomLabel20";
            this.bunifuCustomLabel20.Size = new System.Drawing.Size(92, 16);
            this.bunifuCustomLabel20.TabIndex = 101;
            this.bunifuCustomLabel20.Text = "Feedback to Us";
            // 
            // bunifuSeparator67
            // 
            this.bunifuSeparator67.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator67.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator67.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator67.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator67.LineThickness = 1;
            this.bunifuSeparator67.Location = new System.Drawing.Point(268, 12);
            this.bunifuSeparator67.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator67.Name = "bunifuSeparator67";
            this.bunifuSeparator67.Size = new System.Drawing.Size(654, 15);
            this.bunifuSeparator67.TabIndex = 100;
            this.bunifuSeparator67.Transparency = 255;
            this.bunifuSeparator67.Vertical = false;
            // 
            // bunifuSeparator65
            // 
            this.bunifuSeparator65.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator65.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator65.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator65.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator65.LineThickness = 1;
            this.bunifuSeparator65.Location = new System.Drawing.Point(279, 122);
            this.bunifuSeparator65.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator65.Name = "bunifuSeparator65";
            this.bunifuSeparator65.Size = new System.Drawing.Size(10, 257);
            this.bunifuSeparator65.TabIndex = 97;
            this.bunifuSeparator65.Transparency = 255;
            this.bunifuSeparator65.Vertical = true;
            // 
            // bunifuCustomLabel19
            // 
            this.bunifuCustomLabel19.AutoSize = true;
            this.bunifuCustomLabel19.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel19.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel19.Location = new System.Drawing.Point(326, 114);
            this.bunifuCustomLabel19.Name = "bunifuCustomLabel19";
            this.bunifuCustomLabel19.Size = new System.Drawing.Size(56, 16);
            this.bunifuCustomLabel19.TabIndex = 96;
            this.bunifuCustomLabel19.Text = "Message";
            // 
            // bunifuSeparator64
            // 
            this.bunifuSeparator64.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator64.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator64.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator64.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator64.LineThickness = 1;
            this.bunifuSeparator64.Location = new System.Drawing.Point(284, 114);
            this.bunifuSeparator64.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator64.Name = "bunifuSeparator64";
            this.bunifuSeparator64.Size = new System.Drawing.Size(622, 15);
            this.bunifuSeparator64.TabIndex = 95;
            this.bunifuSeparator64.Transparency = 255;
            this.bunifuSeparator64.Vertical = false;
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(326, 35);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(49, 16);
            this.bunifuCustomLabel18.TabIndex = 94;
            this.bunifuCustomLabel18.Text = "Review";
            // 
            // bunifuSeparator60
            // 
            this.bunifuSeparator60.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator60.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator60.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator60.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator60.LineThickness = 1;
            this.bunifuSeparator60.Location = new System.Drawing.Point(284, 96);
            this.bunifuSeparator60.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator60.Name = "bunifuSeparator60";
            this.bunifuSeparator60.Size = new System.Drawing.Size(622, 10);
            this.bunifuSeparator60.TabIndex = 91;
            this.bunifuSeparator60.Transparency = 255;
            this.bunifuSeparator60.Vertical = false;
            // 
            // bunifuSeparator61
            // 
            this.bunifuSeparator61.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator61.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator61.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator61.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator61.LineThickness = 1;
            this.bunifuSeparator61.Location = new System.Drawing.Point(284, 35);
            this.bunifuSeparator61.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator61.Name = "bunifuSeparator61";
            this.bunifuSeparator61.Size = new System.Drawing.Size(622, 15);
            this.bunifuSeparator61.TabIndex = 90;
            this.bunifuSeparator61.Transparency = 255;
            this.bunifuSeparator61.Vertical = false;
            // 
            // bunifuSeparator62
            // 
            this.bunifuSeparator62.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator62.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator62.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator62.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator62.LineThickness = 1;
            this.bunifuSeparator62.Location = new System.Drawing.Point(901, 42);
            this.bunifuSeparator62.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator62.Name = "bunifuSeparator62";
            this.bunifuSeparator62.Size = new System.Drawing.Size(10, 59);
            this.bunifuSeparator62.TabIndex = 93;
            this.bunifuSeparator62.Transparency = 255;
            this.bunifuSeparator62.Vertical = true;
            // 
            // bunifuSeparator63
            // 
            this.bunifuSeparator63.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator63.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator63.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator63.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator63.LineThickness = 1;
            this.bunifuSeparator63.Location = new System.Drawing.Point(278, 42);
            this.bunifuSeparator63.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator63.Name = "bunifuSeparator63";
            this.bunifuSeparator63.Size = new System.Drawing.Size(10, 59);
            this.bunifuSeparator63.TabIndex = 92;
            this.bunifuSeparator63.Transparency = 255;
            this.bunifuSeparator63.Vertical = true;
            // 
            // Star5
            // 
            this.Star5.AutoSize = true;
            this.Star5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Star5.ForeColor = System.Drawing.Color.Silver;
            this.Star5.Location = new System.Drawing.Point(806, 80);
            this.Star5.Name = "Star5";
            this.Star5.Size = new System.Drawing.Size(91, 20);
            this.Star5.TabIndex = 89;
            this.Star5.TabStop = true;
            this.Star5.Text = "+5 ★★★★★";
            this.Star5.UseVisualStyleBackColor = true;
            // 
            // Star4
            // 
            this.Star4.AutoSize = true;
            this.Star4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Star4.ForeColor = System.Drawing.Color.Silver;
            this.Star4.Location = new System.Drawing.Point(806, 54);
            this.Star4.Name = "Star4";
            this.Star4.Size = new System.Drawing.Size(81, 20);
            this.Star4.TabIndex = 88;
            this.Star4.TabStop = true;
            this.Star4.Text = "+4 ★★★★";
            this.Star4.UseVisualStyleBackColor = true;
            // 
            // Star3
            // 
            this.Star3.AutoSize = true;
            this.Star3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Star3.ForeColor = System.Drawing.Color.Silver;
            this.Star3.Location = new System.Drawing.Point(736, 54);
            this.Star3.Name = "Star3";
            this.Star3.Size = new System.Drawing.Size(71, 20);
            this.Star3.TabIndex = 87;
            this.Star3.TabStop = true;
            this.Star3.Text = "+3 ★★★";
            this.Star3.UseVisualStyleBackColor = true;
            // 
            // Star2
            // 
            this.Star2.AutoSize = true;
            this.Star2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Star2.ForeColor = System.Drawing.Color.Silver;
            this.Star2.Location = new System.Drawing.Point(669, 53);
            this.Star2.Name = "Star2";
            this.Star2.Size = new System.Drawing.Size(61, 20);
            this.Star2.TabIndex = 86;
            this.Star2.TabStop = true;
            this.Star2.Text = "+2 ★★";
            this.Star2.UseVisualStyleBackColor = true;
            // 
            // Star1
            // 
            this.Star1.AutoSize = true;
            this.Star1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Star1.ForeColor = System.Drawing.Color.Silver;
            this.Star1.Location = new System.Drawing.Point(612, 53);
            this.Star1.Name = "Star1";
            this.Star1.Size = new System.Drawing.Size(51, 20);
            this.Star1.TabIndex = 85;
            this.Star1.TabStop = true;
            this.Star1.Text = "+1 ★";
            this.Star1.UseVisualStyleBackColor = true;
            // 
            // txtName
            // 
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtName.ForeColor = System.Drawing.Color.Silver;
            this.txtName.HintForeColor = System.Drawing.Color.Silver;
            this.txtName.HintText = "Insert yourname";
            this.txtName.isPassword = false;
            this.txtName.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtName.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtName.LineThickness = 3;
            this.txtName.Location = new System.Drawing.Point(382, 40);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(211, 34);
            this.txtName.TabIndex = 1;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(291, 56);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(84, 17);
            this.bunifuCustomLabel17.TabIndex = 83;
            this.bunifuCustomLabel17.Text = "Your Name:";
            // 
            // btnFeedback
            // 
            this.btnFeedback.ActiveBorderThickness = 1;
            this.btnFeedback.ActiveCornerRadius = 20;
            this.btnFeedback.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnFeedback.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnFeedback.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnFeedback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnFeedback.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFeedback.BackgroundImage")));
            this.btnFeedback.ButtonText = "Send Feedback";
            this.btnFeedback.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFeedback.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFeedback.ForeColor = System.Drawing.Color.Silver;
            this.btnFeedback.IdleBorderThickness = 1;
            this.btnFeedback.IdleCornerRadius = 20;
            this.btnFeedback.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnFeedback.IdleForecolor = System.Drawing.Color.Silver;
            this.btnFeedback.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnFeedback.Location = new System.Drawing.Point(739, 326);
            this.btnFeedback.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnFeedback.Name = "btnFeedback";
            this.btnFeedback.Size = new System.Drawing.Size(151, 46);
            this.btnFeedback.TabIndex = 82;
            this.btnFeedback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFeedback.Click += new System.EventHandler(this.btnFeedback_Click);
            // 
            // txtFeedbackMessage
            // 
            this.txtFeedbackMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.txtFeedbackMessage.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.txtFeedbackMessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFeedbackMessage.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeedbackMessage.ForeColor = System.Drawing.Color.Silver;
            this.txtFeedbackMessage.Location = new System.Drawing.Point(308, 198);
            this.txtFeedbackMessage.Multiline = true;
            this.txtFeedbackMessage.Name = "txtFeedbackMessage";
            this.txtFeedbackMessage.Size = new System.Drawing.Size(564, 122);
            this.txtFeedbackMessage.TabIndex = 3;
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(316, 173);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(102, 17);
            this.bunifuCustomLabel15.TabIndex = 80;
            this.bunifuCustomLabel15.Text = "Message Body:";
            // 
            // txtSubject
            // 
            this.txtSubject.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSubject.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtSubject.ForeColor = System.Drawing.Color.Silver;
            this.txtSubject.HintForeColor = System.Drawing.Color.Silver;
            this.txtSubject.HintText = "Type your subject";
            this.txtSubject.isPassword = false;
            this.txtSubject.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtSubject.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSubject.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.txtSubject.LineThickness = 3;
            this.txtSubject.Location = new System.Drawing.Point(416, 125);
            this.txtSubject.Margin = new System.Windows.Forms.Padding(4);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(456, 34);
            this.txtSubject.TabIndex = 2;
            this.txtSubject.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel16.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(350, 142);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(59, 17);
            this.bunifuCustomLabel16.TabIndex = 78;
            this.bunifuCustomLabel16.Text = "Subject:";
            // 
            // bunifuSeparator66
            // 
            this.bunifuSeparator66.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator66.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator66.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator66.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator66.LineThickness = 1;
            this.bunifuSeparator66.Location = new System.Drawing.Point(901, 121);
            this.bunifuSeparator66.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator66.Name = "bunifuSeparator66";
            this.bunifuSeparator66.Size = new System.Drawing.Size(10, 257);
            this.bunifuSeparator66.TabIndex = 98;
            this.bunifuSeparator66.Transparency = 255;
            this.bunifuSeparator66.Vertical = true;
            // 
            // bunifuSeparator59
            // 
            this.bunifuSeparator59.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator59.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator59.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator59.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator59.LineThickness = 1;
            this.bunifuSeparator59.Location = new System.Drawing.Point(285, 372);
            this.bunifuSeparator59.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator59.Name = "bunifuSeparator59";
            this.bunifuSeparator59.Size = new System.Drawing.Size(622, 15);
            this.bunifuSeparator59.TabIndex = 99;
            this.bunifuSeparator59.Transparency = 255;
            this.bunifuSeparator59.Vertical = false;
            // 
            // bunifuSeparator68
            // 
            this.bunifuSeparator68.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator68.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator68.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator68.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator68.LineThickness = 1;
            this.bunifuSeparator68.Location = new System.Drawing.Point(262, 19);
            this.bunifuSeparator68.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator68.Name = "bunifuSeparator68";
            this.bunifuSeparator68.Size = new System.Drawing.Size(10, 381);
            this.bunifuSeparator68.TabIndex = 102;
            this.bunifuSeparator68.Transparency = 255;
            this.bunifuSeparator68.Vertical = true;
            // 
            // bunifuSeparator69
            // 
            this.bunifuSeparator69.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator69.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator69.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator69.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator69.LineThickness = 1;
            this.bunifuSeparator69.Location = new System.Drawing.Point(917, 19);
            this.bunifuSeparator69.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator69.Name = "bunifuSeparator69";
            this.bunifuSeparator69.Size = new System.Drawing.Size(10, 381);
            this.bunifuSeparator69.TabIndex = 103;
            this.bunifuSeparator69.Transparency = 255;
            this.bunifuSeparator69.Vertical = true;
            // 
            // bunifuSeparator70
            // 
            this.bunifuSeparator70.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator70.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator70.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator70.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator70.LineThickness = 1;
            this.bunifuSeparator70.Location = new System.Drawing.Point(268, 393);
            this.bunifuSeparator70.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator70.Name = "bunifuSeparator70";
            this.bunifuSeparator70.Size = new System.Drawing.Size(655, 15);
            this.bunifuSeparator70.TabIndex = 104;
            this.bunifuSeparator70.Transparency = 255;
            this.bunifuSeparator70.Vertical = false;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.tabPage4.Controls.Add(this.bunifuCustomLabel28);
            this.tabPage4.Controls.Add(this.bunifuSeparator78);
            this.tabPage4.Controls.Add(this.bunifuSeparator75);
            this.tabPage4.Controls.Add(this.btnFacebook);
            this.tabPage4.Controls.Add(this.btnWeb);
            this.tabPage4.Controls.Add(this.btnDonate);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel27);
            this.tabPage4.Controls.Add(this.bunifuSeparator71);
            this.tabPage4.Controls.Add(this.bunifuSeparator72);
            this.tabPage4.Controls.Add(this.bunifuSeparator73);
            this.tabPage4.Controls.Add(this.bunifuSeparator74);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel26);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel25);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel24);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel23);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel22);
            this.tabPage4.Controls.Add(this.bunifuCustomLabel21);
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.bunifuSeparator76);
            this.tabPage4.Controls.Add(this.bunifuSeparator77);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(942, 573);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "About";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // bunifuCustomLabel28
            // 
            this.bunifuCustomLabel28.AutoSize = true;
            this.bunifuCustomLabel28.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel28.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel28.Location = new System.Drawing.Point(367, 237);
            this.bunifuCustomLabel28.Name = "bunifuCustomLabel28";
            this.bunifuCustomLabel28.Size = new System.Drawing.Size(64, 16);
            this.bunifuCustomLabel28.TabIndex = 117;
            this.bunifuCustomLabel28.Text = "Donate Us";
            // 
            // bunifuSeparator78
            // 
            this.bunifuSeparator78.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator78.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator78.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator78.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator78.LineThickness = 1;
            this.bunifuSeparator78.Location = new System.Drawing.Point(335, 389);
            this.bunifuSeparator78.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator78.Name = "bunifuSeparator78";
            this.bunifuSeparator78.Size = new System.Drawing.Size(523, 15);
            this.bunifuSeparator78.TabIndex = 116;
            this.bunifuSeparator78.Transparency = 255;
            this.bunifuSeparator78.Vertical = false;
            // 
            // bunifuSeparator75
            // 
            this.bunifuSeparator75.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator75.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator75.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator75.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator75.LineThickness = 1;
            this.bunifuSeparator75.Location = new System.Drawing.Point(335, 240);
            this.bunifuSeparator75.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator75.Name = "bunifuSeparator75";
            this.bunifuSeparator75.Size = new System.Drawing.Size(523, 15);
            this.bunifuSeparator75.TabIndex = 113;
            this.bunifuSeparator75.Transparency = 255;
            this.bunifuSeparator75.Vertical = false;
            // 
            // btnFacebook
            // 
            this.btnFacebook.ActiveBorderThickness = 1;
            this.btnFacebook.ActiveCornerRadius = 20;
            this.btnFacebook.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnFacebook.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnFacebook.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnFacebook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnFacebook.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFacebook.BackgroundImage")));
            this.btnFacebook.ButtonText = "Facebook";
            this.btnFacebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFacebook.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFacebook.ForeColor = System.Drawing.Color.Silver;
            this.btnFacebook.IdleBorderThickness = 1;
            this.btnFacebook.IdleCornerRadius = 20;
            this.btnFacebook.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnFacebook.IdleForecolor = System.Drawing.Color.Silver;
            this.btnFacebook.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnFacebook.Location = new System.Drawing.Point(680, 335);
            this.btnFacebook.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnFacebook.Name = "btnFacebook";
            this.btnFacebook.Size = new System.Drawing.Size(151, 46);
            this.btnFacebook.TabIndex = 112;
            this.btnFacebook.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFacebook.Click += new System.EventHandler(this.btnFacebook_Click);
            // 
            // btnWeb
            // 
            this.btnWeb.ActiveBorderThickness = 1;
            this.btnWeb.ActiveCornerRadius = 20;
            this.btnWeb.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnWeb.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnWeb.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnWeb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnWeb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWeb.BackgroundImage")));
            this.btnWeb.ButtonText = "Website";
            this.btnWeb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWeb.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWeb.ForeColor = System.Drawing.Color.Silver;
            this.btnWeb.IdleBorderThickness = 1;
            this.btnWeb.IdleCornerRadius = 20;
            this.btnWeb.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnWeb.IdleForecolor = System.Drawing.Color.Silver;
            this.btnWeb.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnWeb.Location = new System.Drawing.Point(370, 335);
            this.btnWeb.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnWeb.Name = "btnWeb";
            this.btnWeb.Size = new System.Drawing.Size(151, 46);
            this.btnWeb.TabIndex = 111;
            this.btnWeb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnWeb.Click += new System.EventHandler(this.btnWeb_Click);
            // 
            // btnDonate
            // 
            this.btnDonate.ActiveBorderThickness = 1;
            this.btnDonate.ActiveCornerRadius = 20;
            this.btnDonate.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnDonate.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDonate.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnDonate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnDonate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDonate.BackgroundImage")));
            this.btnDonate.ButtonText = "Donate Now";
            this.btnDonate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDonate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDonate.ForeColor = System.Drawing.Color.Silver;
            this.btnDonate.IdleBorderThickness = 1;
            this.btnDonate.IdleCornerRadius = 20;
            this.btnDonate.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnDonate.IdleForecolor = System.Drawing.Color.Silver;
            this.btnDonate.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnDonate.Location = new System.Drawing.Point(525, 304);
            this.btnDonate.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnDonate.Name = "btnDonate";
            this.btnDonate.Size = new System.Drawing.Size(151, 46);
            this.btnDonate.TabIndex = 110;
            this.btnDonate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDonate.Click += new System.EventHandler(this.btnDonate_Click);
            // 
            // bunifuCustomLabel27
            // 
            this.bunifuCustomLabel27.AutoSize = true;
            this.bunifuCustomLabel27.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel27.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel27.Location = new System.Drawing.Point(332, 4);
            this.bunifuCustomLabel27.Name = "bunifuCustomLabel27";
            this.bunifuCustomLabel27.Size = new System.Drawing.Size(56, 16);
            this.bunifuCustomLabel27.TabIndex = 106;
            this.bunifuCustomLabel27.Text = "About Us";
            // 
            // bunifuSeparator71
            // 
            this.bunifuSeparator71.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator71.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator71.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator71.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator71.LineThickness = 1;
            this.bunifuSeparator71.Location = new System.Drawing.Point(301, 4);
            this.bunifuSeparator71.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator71.Name = "bunifuSeparator71";
            this.bunifuSeparator71.Size = new System.Drawing.Size(589, 15);
            this.bunifuSeparator71.TabIndex = 105;
            this.bunifuSeparator71.Transparency = 255;
            this.bunifuSeparator71.Vertical = false;
            // 
            // bunifuSeparator72
            // 
            this.bunifuSeparator72.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator72.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator72.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator72.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator72.LineThickness = 1;
            this.bunifuSeparator72.Location = new System.Drawing.Point(295, 12);
            this.bunifuSeparator72.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator72.Name = "bunifuSeparator72";
            this.bunifuSeparator72.Size = new System.Drawing.Size(10, 405);
            this.bunifuSeparator72.TabIndex = 107;
            this.bunifuSeparator72.Transparency = 255;
            this.bunifuSeparator72.Vertical = true;
            // 
            // bunifuSeparator73
            // 
            this.bunifuSeparator73.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator73.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator73.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator73.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator73.LineThickness = 1;
            this.bunifuSeparator73.Location = new System.Drawing.Point(885, 11);
            this.bunifuSeparator73.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator73.Name = "bunifuSeparator73";
            this.bunifuSeparator73.Size = new System.Drawing.Size(10, 405);
            this.bunifuSeparator73.TabIndex = 108;
            this.bunifuSeparator73.Transparency = 255;
            this.bunifuSeparator73.Vertical = true;
            // 
            // bunifuSeparator74
            // 
            this.bunifuSeparator74.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator74.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator74.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator74.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator74.LineThickness = 1;
            this.bunifuSeparator74.Location = new System.Drawing.Point(300, 410);
            this.bunifuSeparator74.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator74.Name = "bunifuSeparator74";
            this.bunifuSeparator74.Size = new System.Drawing.Size(591, 15);
            this.bunifuSeparator74.TabIndex = 109;
            this.bunifuSeparator74.Transparency = 255;
            this.bunifuSeparator74.Vertical = false;
            // 
            // bunifuCustomLabel26
            // 
            this.bunifuCustomLabel26.AutoSize = true;
            this.bunifuCustomLabel26.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel26.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel26.Location = new System.Drawing.Point(522, 284);
            this.bunifuCustomLabel26.Name = "bunifuCustomLabel26";
            this.bunifuCustomLabel26.Size = new System.Drawing.Size(166, 17);
            this.bunifuCustomLabel26.TabIndex = 26;
            this.bunifuCustomLabel26.Text = "Bolt Number: 9993553113";
            // 
            // bunifuCustomLabel25
            // 
            this.bunifuCustomLabel25.AutoSize = true;
            this.bunifuCustomLabel25.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel25.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel25.Location = new System.Drawing.Point(547, 259);
            this.bunifuCustomLabel25.Name = "bunifuCustomLabel25";
            this.bunifuCustomLabel25.Size = new System.Drawing.Size(107, 25);
            this.bunifuCustomLabel25.TabIndex = 25;
            this.bunifuCustomLabel25.Text = "Pulsa Bolt";
            // 
            // bunifuCustomLabel24
            // 
            this.bunifuCustomLabel24.AutoSize = true;
            this.bunifuCustomLabel24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel24.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel24.Location = new System.Drawing.Point(501, 212);
            this.bunifuCustomLabel24.Name = "bunifuCustomLabel24";
            this.bunifuCustomLabel24.Size = new System.Drawing.Size(198, 17);
            this.bunifuCustomLabel24.TabIndex = 24;
            this.bunifuCustomLabel24.Text = "Copyright © 2017 Yurani Corp";
            // 
            // bunifuCustomLabel23
            // 
            this.bunifuCustomLabel23.AutoSize = true;
            this.bunifuCustomLabel23.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel23.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel23.Location = new System.Drawing.Point(515, 195);
            this.bunifuCustomLabel23.Name = "bunifuCustomLabel23";
            this.bunifuCustomLabel23.Size = new System.Drawing.Size(173, 17);
            this.bunifuCustomLabel23.TabIndex = 23;
            this.bunifuCustomLabel23.Text = "Developer: Yusril Takeuchi";
            // 
            // bunifuCustomLabel22
            // 
            this.bunifuCustomLabel22.AutoSize = true;
            this.bunifuCustomLabel22.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel22.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel22.Location = new System.Drawing.Point(554, 178);
            this.bunifuCustomLabel22.Name = "bunifuCustomLabel22";
            this.bunifuCustomLabel22.Size = new System.Drawing.Size(100, 17);
            this.bunifuCustomLabel22.TabIndex = 22;
            this.bunifuCustomLabel22.Text = "Version: V1.0.0";
            // 
            // bunifuCustomLabel21
            // 
            this.bunifuCustomLabel21.AutoSize = true;
            this.bunifuCustomLabel21.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel21.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel21.Location = new System.Drawing.Point(547, 145);
            this.bunifuCustomLabel21.Name = "bunifuCustomLabel21";
            this.bunifuCustomLabel21.Size = new System.Drawing.Size(115, 28);
            this.bunifuCustomLabel21.TabIndex = 21;
            this.bunifuCustomLabel21.Text = "Amnesia";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(371, -89);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(476, 345);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // bunifuSeparator76
            // 
            this.bunifuSeparator76.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator76.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator76.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator76.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator76.LineThickness = 1;
            this.bunifuSeparator76.Location = new System.Drawing.Point(329, 247);
            this.bunifuSeparator76.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator76.Name = "bunifuSeparator76";
            this.bunifuSeparator76.Size = new System.Drawing.Size(10, 150);
            this.bunifuSeparator76.TabIndex = 114;
            this.bunifuSeparator76.Transparency = 255;
            this.bunifuSeparator76.Vertical = true;
            // 
            // bunifuSeparator77
            // 
            this.bunifuSeparator77.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator77.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator77.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator77.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator77.LineThickness = 1;
            this.bunifuSeparator77.Location = new System.Drawing.Point(853, 247);
            this.bunifuSeparator77.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator77.Name = "bunifuSeparator77";
            this.bunifuSeparator77.Size = new System.Drawing.Size(10, 150);
            this.bunifuSeparator77.TabIndex = 115;
            this.bunifuSeparator77.Transparency = 255;
            this.bunifuSeparator77.Vertical = true;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.tabPage5.Controls.Add(this.bunifuCustomLabel32);
            this.tabPage5.Controls.Add(this.bunifuSeparator81);
            this.tabPage5.Controls.Add(this.bunifuSeparator79);
            this.tabPage5.Controls.Add(this.bunifuCustomLabel31);
            this.tabPage5.Controls.Add(this.updateLabel);
            this.tabPage5.Controls.Add(this.labelMyVersion);
            this.tabPage5.Controls.Add(this.btnUpdate);
            this.tabPage5.Controls.Add(this.pictureBox4);
            this.tabPage5.Controls.Add(this.bunifuSeparator80);
            this.tabPage5.Controls.Add(this.bunifuSeparator82);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(942, 573);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Update";
            // 
            // bunifuCustomLabel32
            // 
            this.bunifuCustomLabel32.AutoSize = true;
            this.bunifuCustomLabel32.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel32.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel32.Location = new System.Drawing.Point(419, 36);
            this.bunifuCustomLabel32.Name = "bunifuCustomLabel32";
            this.bunifuCustomLabel32.Size = new System.Drawing.Size(91, 16);
            this.bunifuCustomLabel32.TabIndex = 119;
            this.bunifuCustomLabel32.Text = "Update System";
            // 
            // bunifuSeparator81
            // 
            this.bunifuSeparator81.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator81.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator81.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator81.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator81.LineThickness = 1;
            this.bunifuSeparator81.Location = new System.Drawing.Point(393, 345);
            this.bunifuSeparator81.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator81.Name = "bunifuSeparator81";
            this.bunifuSeparator81.Size = new System.Drawing.Size(441, 15);
            this.bunifuSeparator81.TabIndex = 117;
            this.bunifuSeparator81.Transparency = 255;
            this.bunifuSeparator81.Vertical = false;
            // 
            // bunifuSeparator79
            // 
            this.bunifuSeparator79.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator79.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator79.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator79.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator79.LineThickness = 1;
            this.bunifuSeparator79.Location = new System.Drawing.Point(393, 36);
            this.bunifuSeparator79.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator79.Name = "bunifuSeparator79";
            this.bunifuSeparator79.Size = new System.Drawing.Size(441, 15);
            this.bunifuSeparator79.TabIndex = 115;
            this.bunifuSeparator79.Transparency = 255;
            this.bunifuSeparator79.Vertical = false;
            // 
            // bunifuCustomLabel31
            // 
            this.bunifuCustomLabel31.AutoSize = true;
            this.bunifuCustomLabel31.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel31.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel31.Location = new System.Drawing.Point(506, 66);
            this.bunifuCustomLabel31.Name = "bunifuCustomLabel31";
            this.bunifuCustomLabel31.Size = new System.Drawing.Size(190, 28);
            this.bunifuCustomLabel31.TabIndex = 114;
            this.bunifuCustomLabel31.Text = "Update Version";
            // 
            // updateLabel
            // 
            this.updateLabel.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateLabel.ForeColor = System.Drawing.Color.Silver;
            this.updateLabel.Location = new System.Drawing.Point(496, 305);
            this.updateLabel.Name = "updateLabel";
            this.updateLabel.Size = new System.Drawing.Size(217, 17);
            this.updateLabel.TabIndex = 113;
            this.updateLabel.Text = "Can\'t connect to Server";
            this.updateLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelMyVersion
            // 
            this.labelMyVersion.AutoSize = true;
            this.labelMyVersion.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMyVersion.ForeColor = System.Drawing.Color.Silver;
            this.labelMyVersion.Location = new System.Drawing.Point(537, 288);
            this.labelMyVersion.Name = "labelMyVersion";
            this.labelMyVersion.Size = new System.Drawing.Size(132, 17);
            this.labelMyVersion.TabIndex = 112;
            this.labelMyVersion.Text = "Your Version: V1.0.0";
            // 
            // btnUpdate
            // 
            this.btnUpdate.ActiveBorderThickness = 1;
            this.btnUpdate.ActiveCornerRadius = 20;
            this.btnUpdate.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnUpdate.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUpdate.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.btnUpdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdate.BackgroundImage")));
            this.btnUpdate.ButtonText = "Update Now";
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.Silver;
            this.btnUpdate.IdleBorderThickness = 1;
            this.btnUpdate.IdleCornerRadius = 20;
            this.btnUpdate.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(60)))), ((int)(((byte)(97)))));
            this.btnUpdate.IdleForecolor = System.Drawing.Color.Silver;
            this.btnUpdate.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.btnUpdate.Location = new System.Drawing.Point(526, 239);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(151, 46);
            this.btnUpdate.TabIndex = 111;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(533, 97);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(140, 136);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // bunifuSeparator80
            // 
            this.bunifuSeparator80.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator80.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator80.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator80.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator80.LineThickness = 1;
            this.bunifuSeparator80.Location = new System.Drawing.Point(387, 43);
            this.bunifuSeparator80.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator80.Name = "bunifuSeparator80";
            this.bunifuSeparator80.Size = new System.Drawing.Size(10, 309);
            this.bunifuSeparator80.TabIndex = 116;
            this.bunifuSeparator80.Transparency = 255;
            this.bunifuSeparator80.Vertical = true;
            // 
            // bunifuSeparator82
            // 
            this.bunifuSeparator82.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator82.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSeparator82.ForeColor = System.Drawing.Color.Silver;
            this.bunifuSeparator82.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(104)))), ((int)(((byte)(204)))));
            this.bunifuSeparator82.LineThickness = 1;
            this.bunifuSeparator82.Location = new System.Drawing.Point(829, 44);
            this.bunifuSeparator82.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuSeparator82.Name = "bunifuSeparator82";
            this.bunifuSeparator82.Size = new System.Drawing.Size(10, 309);
            this.bunifuSeparator82.TabIndex = 118;
            this.bunifuSeparator82.Transparency = 255;
            this.bunifuSeparator82.Vertical = true;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Zip|*.zip";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.ClientSize = new System.Drawing.Size(938, 607);
            this.Controls.Add(this.panelUp);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(938, 607);
            this.MinimumSize = new System.Drawing.Size(938, 607);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Amnesia";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelUp.ResumeLayout(false);
            this.panelUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListView listView1;
        private ns1.BunifuElipse bunifuElipse1;
        private ns1.BunifuMaterialTextbox txtToken;
        private ns1.BunifuGradientPanel panelUp;
        private ns1.BunifuMaterialTextbox txtAmount;
        private ns1.BunifuSlider amountSlider;
        private ns1.BunifuCustomLabel lblName;
        private ns1.BunifuCustomLabel lblID;
        private ns1.BunifuSeparator bunifuSeparator1;
        private ns1.BunifuProgressBar progressBar;
        private ns1.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private ns1.BunifuImageButton btnExit;
        private ns1.BunifuFlatButton tabRemove;
        private ns1.BunifuFlatButton tabPost;
        private ns1.BunifuFlatButton tabAbout;
        private ns1.BunifuFlatButton tabExit;
        private ns1.BunifuSeparator bunifuSeparator2;
        private ns1.BunifuSeparator bunifuSeparator3;
        private ns1.BunifuSeparator bunifuSeparator4;
        private ns1.BunifuSeparator bunifuSeparator5;
        private System.Windows.Forms.Panel panel1;
        private ns1.BunifuThinButton2 btnGetAccess;
        private ns1.BunifuThinButton2 btnRemoveAll;
        private ns1.BunifuSeparator bunifuSeparator7;
        private ns1.BunifuSeparator bunifuSeparator6;
        private ns1.BunifuSeparator bunifuSeparator8;
        private ns1.BunifuSeparator bunifuSeparator9;
        private ns1.BunifuCustomLabel bunifuCustomLabel2;
        private ns1.BunifuSeparator bunifuSeparator11;
        private ns1.BunifuSeparator bunifuSeparator10;
        private ns1.BunifuSeparator bunifuSeparator12;
        private ns1.BunifuSeparator bunifuSeparator13;
        private ns1.BunifuCustomLabel bunifuCustomLabel3;
        private ns1.BunifuSeparator bunifuSeparator15;
        private ns1.BunifuSeparator bunifuSeparator14;
        private ns1.BunifuSeparator bunifuSeparator16;
        private ns1.BunifuSeparator bunifuSeparator17;
        private ns1.BunifuCustomLabel bunifuCustomLabel4;
        private ns1.BunifuDropdown dropdownListPost;
        private ns1.BunifuThinButton2 btnAdd;
        private ns1.BunifuThinButton2 btnRemove;
        private ns1.BunifuSeparator bunifuSeparator19;
        private ns1.BunifuSeparator bunifuSeparator18;
        private ns1.BunifuSeparator bunifuSeparator20;
        private ns1.BunifuSeparator bunifuSeparator21;
        private ns1.BunifuCustomLabel bunifuCustomLabel5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private ns1.BunifuFlatButton tabFeedback;
        private ns1.BunifuMaterialTextbox txtToken2;
        private ns1.BunifuCustomLabel bunifuCustomLabel6;
        private ns1.BunifuSeparator bunifuSeparator22;
        private ns1.BunifuSeparator bunifuSeparator23;
        private ns1.BunifuThinButton2 btnGetAccessToken2;
        private ns1.BunifuSeparator bunifuSeparator24;
        private ns1.BunifuSeparator bunifuSeparator25;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private ns1.BunifuCustomLabel bunifuCustomLabel7;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txtMessage;
        private ns1.BunifuCustomLabel bunifuCustomLabel8;
        private ns1.BunifuProgressBar progressBar2;
        private ns1.BunifuSeparator bunifuSeparator26;
        private ns1.BunifuSeparator bunifuSeparator27;
        private ns1.BunifuSeparator bunifuSeparator28;
        private ns1.BunifuSeparator bunifuSeparator29;
        private ns1.BunifuSeparator bunifuSeparator30;
        private ns1.BunifuSeparator bunifuSeparator33;
        private ns1.BunifuSeparator bunifuSeparator32;
        private ns1.BunifuSeparator bunifuSeparator31;
        private ns1.BunifuCustomLabel bunifuCustomLabel9;
        private ns1.BunifuSeparator bunifuSeparator34;
        private ns1.BunifuSeparator bunifuSeparator35;
        private ns1.BunifuSeparator bunifuSeparator36;
        private ns1.BunifuThinButton2 btnAddGroup;
        private ns1.BunifuDropdown dropdownGroupList;
        private ns1.BunifuSeparator bunifuSeparator37;
        private ns1.BunifuCustomLabel bunifuCustomLabel10;
        private ns1.BunifuSeparator bunifuSeparator38;
        private ns1.BunifuSeparator bunifuSeparator39;
        private ns1.BunifuMaterialTextbox txtAmountGroups;
        private ns1.BunifuSlider GroupsSlider;
        private ns1.BunifuSeparator bunifuSeparator40;
        private ns1.BunifuSeparator bunifuSeparator41;
        private ns1.BunifuThinButton2 btnSelectAll;
        private ns1.BunifuCustomLabel bunifuCustomLabel11;
        private ns1.BunifuSeparator bunifuSeparator43;
        private ns1.BunifuSeparator bunifuSeparator42;
        private ns1.BunifuThinButton2 btnOKPostType;
        private ns1.BunifuDropdown dropdownPostType;
        private ns1.BunifuSeparator bunifuSeparator44;
        private ns1.BunifuSeparator bunifuSeparator45;
        private ns1.BunifuThinButton2 btnPost;
        private ns1.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.ListView listView2;
        private ns1.BunifuSeparator bunifuSeparator46;
        private ns1.BunifuSeparator bunifuSeparator47;
        private ns1.BunifuSeparator bunifuSeparator49;
        private ns1.BunifuSeparator bunifuSeparator48;
        private ns1.BunifuSeparator bunifuSeparator50;
        private ns1.BunifuCustomLabel lblFriends;
        private System.Windows.Forms.ListBox listBox1;
        private ns1.BunifuCustomLabel bunifuCustomLabel13;
        private ns1.BunifuSeparator bunifuSeparator53;
        private ns1.BunifuSeparator bunifuSeparator51;
        private ns1.BunifuSeparator bunifuSeparator52;
        private ns1.BunifuSeparator bunifuSeparator54;
        private System.Windows.Forms.ListBox listBox2;
        private ns1.BunifuCustomLabel bunifuCustomLabel14;
        private ns1.BunifuSeparator bunifuSeparator55;
        private ns1.BunifuSeparator bunifuSeparator56;
        private ns1.BunifuSeparator bunifuSeparator57;
        private ns1.BunifuSeparator bunifuSeparator58;
        private ns1.BunifuCustomLabel bunifuCustomLabel18;
        private ns1.BunifuSeparator bunifuSeparator60;
        private ns1.BunifuSeparator bunifuSeparator61;
        private ns1.BunifuSeparator bunifuSeparator62;
        private ns1.BunifuSeparator bunifuSeparator63;
        private System.Windows.Forms.RadioButton Star5;
        private System.Windows.Forms.RadioButton Star4;
        private System.Windows.Forms.RadioButton Star3;
        private System.Windows.Forms.RadioButton Star2;
        private System.Windows.Forms.RadioButton Star1;
        private ns1.BunifuMaterialTextbox txtName;
        private ns1.BunifuCustomLabel bunifuCustomLabel17;
        private ns1.BunifuThinButton2 btnFeedback;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txtFeedbackMessage;
        private ns1.BunifuCustomLabel bunifuCustomLabel15;
        private ns1.BunifuMaterialTextbox txtSubject;
        private ns1.BunifuCustomLabel bunifuCustomLabel16;
        private ns1.BunifuSeparator bunifuSeparator65;
        private ns1.BunifuCustomLabel bunifuCustomLabel19;
        private ns1.BunifuSeparator bunifuSeparator64;
        private ns1.BunifuSeparator bunifuSeparator66;
        private ns1.BunifuSeparator bunifuSeparator59;
        private ns1.BunifuCustomLabel bunifuCustomLabel20;
        private ns1.BunifuSeparator bunifuSeparator67;
        private ns1.BunifuSeparator bunifuSeparator68;
        private ns1.BunifuSeparator bunifuSeparator69;
        private ns1.BunifuSeparator bunifuSeparator70;
        private ns1.BunifuThinButton2 btnFacebook;
        private ns1.BunifuThinButton2 btnWeb;
        private ns1.BunifuThinButton2 btnDonate;
        private ns1.BunifuCustomLabel bunifuCustomLabel27;
        private ns1.BunifuSeparator bunifuSeparator71;
        private ns1.BunifuSeparator bunifuSeparator72;
        private ns1.BunifuSeparator bunifuSeparator73;
        private ns1.BunifuSeparator bunifuSeparator74;
        private ns1.BunifuCustomLabel bunifuCustomLabel26;
        private ns1.BunifuCustomLabel bunifuCustomLabel25;
        private ns1.BunifuCustomLabel bunifuCustomLabel24;
        private ns1.BunifuCustomLabel bunifuCustomLabel23;
        private ns1.BunifuCustomLabel bunifuCustomLabel22;
        private ns1.BunifuCustomLabel bunifuCustomLabel21;
        private System.Windows.Forms.PictureBox pictureBox3;
        private ns1.BunifuSeparator bunifuSeparator75;
        private ns1.BunifuSeparator bunifuSeparator76;
        private ns1.BunifuSeparator bunifuSeparator78;
        private ns1.BunifuSeparator bunifuSeparator77;
        private ns1.BunifuCustomLabel bunifuCustomLabel28;
        private ns1.BunifuFlatButton tabUpdate;
        private System.Windows.Forms.TabPage tabPage5;
        private ns1.BunifuCustomLabel bunifuCustomLabel32;
        private ns1.BunifuSeparator bunifuSeparator81;
        private ns1.BunifuSeparator bunifuSeparator79;
        private ns1.BunifuCustomLabel bunifuCustomLabel31;
        private ns1.BunifuCustomLabel updateLabel;
        private ns1.BunifuCustomLabel labelMyVersion;
        private ns1.BunifuThinButton2 btnUpdate;
        private System.Windows.Forms.PictureBox pictureBox4;
        private ns1.BunifuSeparator bunifuSeparator80;
        private ns1.BunifuSeparator bunifuSeparator82;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private ns1.BunifuCustomLabel bunifuCustomLabel1;
    }
}

